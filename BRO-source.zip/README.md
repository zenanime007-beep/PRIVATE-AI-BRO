PRIVATE AI - BRO v0.6.0
Status: source written, NOT yet compiled or tested on a device. See docs/DEVELOPMENT_STATUS.md.
Build: push to GitHub; Actions builds the debug APK (full build first, falls back automatically).
Optional modules: wake=true/false and intel=true/false in gradle.properties.
