plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val wake = (project.findProperty("wake") ?: "true").toString() != "false"
val intel = (project.findProperty("intel") ?: "true").toString() != "false"

android {
    namespace = "com.privateai.bro"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.privateai.bro"
        minSdk = 26
        targetSdk = 33
        versionCode = 6
        versionName = "0.6.0"
        buildConfigField("boolean", "HAS_WAKE", wake.toString())
        buildConfigField("boolean", "HAS_INTEL", intel.toString())
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    sourceSets {
        getByName("main") {
            java.srcDir(if (wake) "src/wake/java" else "src/nowake/java")
            java.srcDir(if (intel) "src/intel/java" else "src/nointel/java")
        }
    }
    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.fragment:fragment-ktx:1.7.1")
    implementation("androidx.biometric:biometric:1.1.0")

    if (wake) {
        // Vosk (Apache-2.0): offline keyword spotting + speaker vectors. Models are downloaded by the user inside the app.
        implementation("net.java.dev.jna:jna:5.13.0@aar")
        implementation("com.alphacephei:vosk-android:0.3.47")
    }
    if (intel) {
        // CameraX + ML Kit on-device models (bundled, no network at runtime).
        implementation("androidx.camera:camera-core:1.3.4")
        implementation("androidx.camera:camera-camera2:1.3.4")
        implementation("androidx.camera:camera-lifecycle:1.3.4")
        implementation("androidx.camera:camera-view:1.3.4")
        implementation("com.google.mlkit:barcode-scanning:17.3.0")
        implementation("com.google.mlkit:text-recognition:16.0.1")
        implementation("com.google.mlkit:image-labeling:17.0.9")
    }
}

// Free OFL fonts (Anton, Space Mono) are fetched at build time; the app falls back to system fonts if this fails.
val fontDir = layout.projectDirectory.dir("src/main/assets/fonts").asFile
tasks.register("fetchFonts") {
    doLast {
        fontDir.mkdirs()
        val base = "https://github.com/google/fonts/raw/main/ofl"
        mapOf(
            "Anton-Regular.ttf" to "$base/anton/Anton-Regular.ttf",
            "SpaceMono-Regular.ttf" to "$base/spacemono/SpaceMono-Regular.ttf",
            "SpaceMono-Bold.ttf" to "$base/spacemono/SpaceMono-Bold.ttf"
        ).forEach { (name, url) ->
            val f = File(fontDir, name)
            if (!f.exists()) {
                try {
                    java.net.URL(url).openStream().use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                } catch (e: Exception) {
                    logger.warn("Font $name not fetched: ${e.message}")
                }
            }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn("fetchFonts") }
