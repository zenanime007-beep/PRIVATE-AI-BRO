package com.privateai.bro

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

@androidx.annotation.OptIn(ExperimentalGetImage::class)
private fun analyze(image: ImageProxy, mode: Int, onResult: (String) -> Unit) {
    val media = image.image
    if (media == null) {
        image.close()
        onResult("NO IMAGE.")
        return
    }
    val input = InputImage.fromMediaImage(media, image.imageInfo.rotationDegrees)
    when (mode) {
        0 -> BarcodeScanning.getClient().process(input)
            .addOnSuccessListener { l ->
                onResult(if (l.isEmpty()) "NO QR OR BARCODE FOUND." else l.joinToString("\n") { it.rawValue ?: "(unreadable)" })
            }
            .addOnFailureListener { onResult("SCAN FAILED.") }
            .addOnCompleteListener { image.close() }
        1 -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(input)
            .addOnSuccessListener { t -> onResult(t.text.ifBlank { "NO TEXT FOUND. (LATIN SCRIPT ONLY, NOT TAMIL.)" }) }
            .addOnFailureListener { onResult("READ FAILED.") }
            .addOnCompleteListener { image.close() }
        else -> ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS).process(input)
            .addOnSuccessListener { l ->
                onResult(
                    if (l.isEmpty()) "NOT SURE WHAT THIS IS."
                    else "LOOKS LIKE: " + l.take(5).joinToString(", ") { "${it.text} ${(it.confidence * 100).toInt()}%" }
                )
            }
            .addOnFailureListener { onResult("RECOGNITION FAILED.") }
            .addOnCompleteListener { image.close() }
    }
}

@Composable
fun LensScreen(fg: Color, head: Color) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var mode by remember { mutableStateOf(Nav.lensMode.coerceIn(0, 2)) }
    var camOk by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    var cameraOn by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }
    val previewView = remember { PreviewView(ctx) }
    val capture = remember { ImageCapture.Builder().build() }

    LaunchedEffect(Nav.lensMode) { mode = Nav.lensMode.coerceIn(0, 2) }

    val camL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        camOk = it
        if (it) cameraOn = true
    }
    val projL = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) {
            val i = Intent(ctx, ScreenCaptureService::class.java).putExtra("code", r.resultCode).putExtra("data", data)
            ctx.startForegroundService(i)
            (ctx as? Activity)?.moveTaskToBack(true)
        } else {
            result = "SCREEN CAPTURE WAS NOT ALLOWED."
        }
    }

    DisposableEffect(cameraOn) {
        var provider: ProcessCameraProvider? = null
        if (cameraOn) {
            val fut = ProcessCameraProvider.getInstance(ctx)
            fut.addListener({
                try {
                    val p = fut.get()
                    provider = p
                    val prev = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                    p.unbindAll()
                    p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, prev, capture)
                } catch (e: Exception) {
                    result = "CAMERA UNAVAILABLE."
                }
            }, ContextCompat.getMainExecutor(ctx))
        }
        onDispose { try { provider?.unbindAll() } catch (e: Exception) {} }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        Display("LENS", 84.sp, head)
        Mono("THE CAMERA OPENS ONLY WHEN YOU TAP. NOTHING IS SAVED OR UPLOADED.", 12.sp, fg, bold = true)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("SCAN QR" to 0, "READ TEXT" to 1, "WHAT IS IT" to 2).forEach { (label, m) ->
                BlockButton(
                    label, Modifier.weight(1f),
                    if (mode == m) Sig.Ink else Color.White, if (mode == m) Sig.Acid else Sig.Ink
                ) { mode = m; result = "" }
            }
        }
        Spacer(Modifier.height(12.dp))
        if (!camOk) {
            BlockButton("ALLOW CAMERA", Modifier.fillMaxWidth()) { camL.launch(Manifest.permission.CAMERA) }
        } else if (!cameraOn) {
            BlockButton("OPEN CAMERA", Modifier.fillMaxWidth()) { cameraOn = true }
        } else {
            androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth().height(320.dp).border(2.dp, Sig.Ink)) {
                AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth()) {
                BlockButton("CAPTURE", Modifier.weight(1f).padding(end = 6.dp)) {
                    if (mode == 2 && !Gate.has(Feature.LENS_LABELS)) {
                        result = "OBJECT LABELS NEED PREMIUM."
                    } else {
                        capture.takePicture(
                            ContextCompat.getMainExecutor(ctx),
                            object : ImageCapture.OnImageCapturedCallback() {
                                override fun onCaptureSuccess(image: ImageProxy) {
                                    analyze(image, mode) { result = it }
                                }
                                override fun onError(exception: ImageCaptureException) {
                                    result = "CAMERA ERROR."
                                }
                            }
                        )
                    }
                }
                BlockButton("CLOSE", Modifier.weight(1f), Color.White, Sig.Ink) { cameraOn = false }
            }
        }
        if (result.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            HardCard(Modifier.fillMaxWidth(), Color.White) { Mono(result, 14.sp, Sig.Ink) }
            Spacer(Modifier.height(8.dp))
            BlockButton("SPEAK IT", Modifier.fillMaxWidth(), Sig.Ink, Sig.Acid) {
                Assistant.say(result.take(300), false)
            }
        }

        Spacer(Modifier.height(28.dp))
        Display("SCREEN", 44.sp, head)
        Spacer(Modifier.height(4.dp))
        Mono(
            "READS THE TEXT ON YOUR SCREEN, ONCE, AFTER YOU ALLOW IT. ANDROID SHOWS ITS OWN CAPTURE NOTICE. " +
                "APPS THAT BLOCK CAPTURE SHOW NOTHING. LATIN SCRIPT ONLY. NO SUMMARY, JUST THE TEXT.",
            11.sp, fg
        )
        Spacer(Modifier.height(8.dp))
        BlockButton("READ MY SCREEN", Modifier.fillMaxWidth()) {
            if (!Gate.has(Feature.SCREEN_READ)) {
                result = "SCREEN READING NEEDS PREMIUM."
            } else {
                projL.launch(ctx.getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
