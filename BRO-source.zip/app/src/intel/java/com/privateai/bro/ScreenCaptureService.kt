package com.privateai.bro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** One-shot screen capture after the user approved Android's capture dialog. The frame is read locally and dropped. */
class ScreenCaptureService : Service() {
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bro_screen", "BRO screen read", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "bro_screen")
            .setContentTitle("BRO is reading your screen once")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(4, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(4, notification())
        }
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            capture(code, data)
        } catch (e: Exception) {
            Assistant.showResult("SCREEN CAPTURE FAILED: ${e.message}", false)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun capture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(code, data)
        proj.registerCallback(object : MediaProjection.Callback() {}, handler)
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val vd = proj.createVirtualDisplay(
            "bro-screen", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, handler
        )
        handler.postDelayed({
            var bmp: Bitmap? = null
            try {
                val img = reader.acquireLatestImage()
                if (img != null) {
                    val pl = img.planes[0]
                    val rowPad = pl.rowStride - pl.pixelStride * w
                    val full = Bitmap.createBitmap(w + rowPad / pl.pixelStride, h, Bitmap.Config.ARGB_8888)
                    full.copyPixelsFromBuffer(pl.buffer)
                    img.close()
                    bmp = Bitmap.createBitmap(full, 0, 0, w, h)
                }
            } catch (e: Exception) {
                bmp = null
            }
            try { vd.release() } catch (e: Exception) {}
            reader.close()
            proj.stop()
            val b = bmp
            if (b == null) {
                Assistant.showResult("COULD NOT CAPTURE THE SCREEN.", false)
                stopSelf()
            } else {
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(b, 0))
                    .addOnSuccessListener { t ->
                        val txt = t.text.trim()
                        if (txt.isEmpty()) {
                            Assistant.showResult("NO READABLE TEXT. THE APP MAY BLOCK SCREEN CAPTURE, OR IT IS NOT LATIN SCRIPT.", false)
                        } else {
                            Assistant.showResult("SCREEN: " + txt.take(600), true)
                        }
                    }
                    .addOnFailureListener { Assistant.showResult("COULD NOT READ THE SCREEN.", false) }
                    .addOnCompleteListener { b.recycle(); stopSelf() }
            }
        }, 1200)
    }
}
