package com.privateai.bro

enum class Level { FREE, PREMIUM, OWNER }

enum class Feature { ORB_THEME, ORB_SIZE, VOICE_PITCH, LENS_LABELS, SCREEN_READ, MORE_ROUTINES, MORE_MEMORY }

/**
 * Local feature entitlement. No payment, no network.
 * The person who completes owner setup on an install is its OWNER. The owner can preview FREE/PREMIUM
 * to test the locks. There is no code or hidden switch that unlocks Premium for someone else.
 */
object Gate {
    fun level(): Level {
        if (!Prefs.ownerSet) return Level.FREE
        return when (Prefs.viewAs) {
            "FREE" -> Level.FREE
            "PREMIUM" -> Level.PREMIUM
            else -> Level.OWNER
        }
    }

    fun has(f: Feature): Boolean = level() != Level.FREE
    fun maxMemory(): Int = if (has(Feature.MORE_MEMORY)) 100 else 20
    fun maxRoutines(): Int = if (has(Feature.MORE_ROUTINES)) 20 else 3
}
