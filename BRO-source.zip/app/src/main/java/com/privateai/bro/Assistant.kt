package com.privateai.bro

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/** Single voice pipeline shared by the app screen and the floating orb. All calls on main thread. */
object Assistant {
    private lateinit var app: Context
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var endAt = 0L

    var state by mutableStateOf(OrbState.IDLE); private set
    var heard by mutableStateOf(""); private set
    var reply by mutableStateOf(""); private set
    /** Normalized speech energy from Android SpeechRecognizer RMS callbacks (0..1). */
    var audioLevel by mutableStateOf(0f); private set

    val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun init(ctx: Context) {
        if (::app.isInitialized) return
        app = ctx.applicationContext
        tts = TextToSpeech(app) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { main.post { setState(OrbState.IDLE) } }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { main.post { setState(OrbState.IDLE) } }
            })
        }
    }

    /** Lets other components (wake service) show a state such as VERIFYING. Call on the main thread. */
    fun external(s: OrbState) {
        if (state == OrbState.IDLE || state == OrbState.VERIFYING) setState(s)
    }

    /** Shows a result in the HOME cards and optionally speaks it. Main thread only. */
    fun showResult(text: String, speakIt: Boolean) {
        reply = text
        if (speakIt) speak(Reply(text.take(400), text.any { it in '\u0B80'..'\u0BFF' }))
    }

    private fun setState(s: OrbState) {
        state = s
        listeners.forEach { it() }
    }

    private fun fail(msg: String) {
        reply = msg
        setState(OrbState.ERROR)
        main.postDelayed({ if (state == OrbState.ERROR) setState(OrbState.IDLE) }, 2500)
    }

    fun hasMic() = ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun activate() {
        if (state == OrbState.LISTENING) {
            recognizer?.stopListening()
            return
        }
        if (!hasMic()) {
            fail("மைக் அனுமதி தேவை. PRIVATE AI ஆப்பைத் திறந்து அனுமதி கொடுங்கள். / Microphone permission needed.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            fail("இந்த போனில் குரல் அறிதல் சேவை இல்லை. / No speech recognition service on this phone.")
            return
        }
        tts?.stop()
        heard = ""
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(app).also { it.setRecognitionListener(listener) }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.langTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        setState(OrbState.WAKE)
        recognizer?.startListening(intent)
        main.postDelayed({ if (state == OrbState.WAKE) setState(OrbState.LISTENING) }, 350)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {
            // RMS is only a visual hint from the speech service, not a recording or identity signal.
            val level = ((rmsdB + 2f) / 14f).coerceIn(0f, 1f)
            audioLevel = audioLevel * 0.58f + level * 0.42f
            listeners.forEach { it() }
        }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { endAt = SystemClock.elapsedRealtime(); audioLevel = 0f; setState(OrbState.THINKING) }
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onPartialResults(partialResults: Bundle?) {
            partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard = it }
        }
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) fail("எதுவும் கேட்கவில்லை. / Didn't catch that.") else handle(text)
        }
        override fun onError(error: Int) {
            audioLevel = 0f
            fail(
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "எதுவும் கேட்கவில்லை. / Didn't catch that."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
                        "இந்த மொழிக்கு offline மாடல் இல்லை போல. / Offline model for this language may be missing."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "மைக் அனுமதி இல்லை. / Microphone permission missing."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy. மீண்டும் முயற்சிக்கவும்."
                    else -> "குரல் பிழை (code $error). / Voice error (code $error)."
                }
            )
        }
    }

    fun say(text: String, tamil: Boolean) {
        reply = text
        speak(Reply(text, tamil))
    }

    private fun handle(text: String) {
        heard = text
        setState(OrbState.EXECUTING)
        val r = CommandEngine.process(app, text)
        if (endAt > 0) Metrics.lastCmdMs = SystemClock.elapsedRealtime() - endAt
        reply = r.text
        speak(r)
    }

    private fun speak(r: Reply) {
        val engine = tts
        if (!ttsReady || engine == null) {
            setState(OrbState.IDLE)
            return
        }
        val loc = if (r.tamil) Locale("ta", "IN") else Locale("en", "IN")
        val avail = engine.setLanguage(loc)
        if (avail == TextToSpeech.LANG_MISSING_DATA || avail == TextToSpeech.LANG_NOT_SUPPORTED) {
            reply = r.text + if (r.tamil) "\n(தமிழ் குரல் இந்த போனில் இல்லை, எழுத்தில் மட்டும்.)" else "\n(Voice not available for this language.)"
            setState(OrbState.IDLE)
            return
        }
        engine.setSpeechRate(Prefs.speechRate)
        engine.setPitch(Prefs.pitch)
        setState(OrbState.SPEAKING)
        engine.speak(r.text, TextToSpeech.QUEUE_FLUSH, null, "bro")
    }

    /** Real detection only; offline recognition per language cannot be queried reliably on Android 12. */
    fun voiceReport(): String {
        val pm = app.packageManager
        val services = pm.queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
            .map { it.serviceInfo.packageName }.distinct()
        val sb = StringBuilder()
        sb.append("Recognition services: ").append(if (services.isEmpty()) "none" else services.joinToString()).append('\n')
        if (Build.VERSION.SDK_INT >= 33) {
            sb.append("On-device recognizer: ").append(SpeechRecognizer.isOnDeviceRecognitionAvailable(app)).append('\n')
        } else {
            sb.append("On-device recognizer check needs Android 13+. Offline Tamil/English must be tested by speaking with airplane mode ON.\n")
        }
        val engine = tts
        if (!ttsReady || engine == null) {
            sb.append("TTS: not ready")
        } else {
            fun st(l: Locale): String = when (engine.isLanguageAvailable(l)) {
                TextToSpeech.LANG_AVAILABLE, TextToSpeech.LANG_COUNTRY_AVAILABLE, TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE -> "available"
                TextToSpeech.LANG_MISSING_DATA -> "voice data missing"
                else -> "not supported"
            }
            sb.append("TTS Tamil: ").append(st(Locale("ta", "IN"))).append('\n')
            sb.append("TTS English (India): ").append(st(Locale("en", "IN")))
        }
        return sb.toString()
    }
}
