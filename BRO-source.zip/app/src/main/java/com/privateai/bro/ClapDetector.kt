package com.privateai.bro

import android.os.SystemClock
import kotlin.math.max
import kotlin.math.sqrt

/** Detects a double clap from 16 kHz mono PCM. Pure signal processing, no model. */
class ClapDetector {
    private var base = 300f
    private var lastPeak = 0L
    private var firstAt = 0L
    private var cooldownUntil = 0L

    fun feed(buf: ShortArray, n: Int): Boolean {
        var hit = false
        val win = 320
        var i = 0
        while (i + win <= n) {
            var sum = 0.0
            for (k in i until i + win) {
                val v = buf[k].toDouble()
                sum += v * v
            }
            val rms = sqrt(sum / win).toFloat()
            val now = SystemClock.elapsedRealtime()
            val thresh = max(2500f, base * 7f)
            if (rms > thresh) {
                if (now - lastPeak > 90) {
                    lastPeak = now
                    if (firstAt != 0L && now - firstAt in 150..700 && now > cooldownUntil) {
                        firstAt = 0L
                        cooldownUntil = now + 2000
                        hit = true
                    } else {
                        firstAt = now
                    }
                }
            } else {
                base = base * .98f + rms * .02f
            }
            if (firstAt != 0L && now - firstAt > 800) firstAt = 0L
            i += win
        }
        return hit
    }
}
