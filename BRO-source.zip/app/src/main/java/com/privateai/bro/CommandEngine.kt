package com.privateai.bro

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Reply(val text: String, val tamil: Boolean)

/** Rule-based offline intent engine (English, Tamil script, Tanglish keywords). */
object CommandEngine {

    private var torchOn = false

    private fun hasTamil(s: String) = s.any { it in '\u0B80'..'\u0BFF' }
    private fun has(s: String, vararg keys: String) = keys.any { s.contains(it) }

    private val tanglishHints = listOf(
        "vanakkam", "neram", "epadi", "enna", "nandri", "yaar", "peru", "indru", "inniku", "pannu", "podu", "kaatu"
    )

    private val numberWords = mapOf(
        "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7,
        "eight" to 8, "nine" to 9, "ten" to 10, "fifteen" to 15, "twenty" to 20, "thirty" to 30
    )

    private val openWords = setOf("open", "launch", "திற", "திறக்க", "திறக்கவும்", "திறங்க", "திறந்து")
    private val stopWords = openWords + setOf("pannu", "பண்ணு", "பண்ணுங்க", "app", "ஆப்", "please", "bro", "the", "my", "ஐ", "ஒபன்")

    private val aliases = mapOf(
        "வாட்ஸ்அப்" to "whatsapp", "வாட்ஸ்ஆப்" to "whatsapp", "யூடியூப்" to "youtube", "யூட்யூப்" to "youtube",
        "கேமரா" to "camera", "குரோம்" to "chrome", "செட்டிங்ஸ்" to "settings", "இன்ஸ்டாகிராம்" to "instagram",
        "கேலரி" to "gallery", "கடிகாரம்" to "clock", "கால்குலேட்டர்" to "calculator", "மேப்ஸ்" to "maps",
        "ஜிமெயில்" to "gmail", "டெலிகிராம்" to "telegram", "ஃபேஸ்புக்" to "facebook"
    )

    private fun firstNumber(s: String): Int? {
        Regex("\\d+").find(s)?.value?.toIntOrNull()?.let { return it }
        return numberWords.entries.firstOrNull { Regex("\\b${it.key}\\b").containsMatchIn(s) }?.value
    }

    private fun start(ctx: Context, i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    private fun torch(ctx: Context, on: Boolean): Boolean {
        return try {
            val cm = ctx.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                val c = cm.getCameraCharacteristics(it)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: return false
            cm.setTorchMode(id, on)
            torchOn = on
            true
        } catch (e: Exception) {
            false
        }
    }

    fun process(ctx: Context, raw: String): Reply {
        val s = raw.lowercase(Locale.ROOT)
            .replace("a.m.", "am").replace("p.m.", "pm").trim()
        val ta = hasTamil(s) || has(s, *tanglishHints.toTypedArray())

        fun r(en: String, tm: String) = Reply(if (ta) tm else en, ta)

        val tokens = s.split(Regex("\\s+")).filter { it.isNotEmpty() }
        Personal.handle(ctx, s, tokens, ta)?.let { return it }

        return when {
            // Flashlight
            has(s, "flashlight", "flash light", "torch", "டார்ச்", "ஃபிளாஷ்", "ஃப்ளாஷ்", "tochu") -> {
                val off = has(s, "off", "அணை", "ஆஃப்", "aaf", "stop")
                val ok = torch(ctx, !off)
                if (!ok) r("I couldn't control the flashlight.", "டார்ச்சைக் கட்டுப்படுத்த முடியவில்லை.")
                else if (off) r("Flashlight off.", "டார்ச் அணைக்கப்பட்டது.")
                else r("Flashlight on.", "டார்ச் எரிகிறது.")
            }
            // Volume
            has(s, "volume", "sound", "வால்யூம்", "சத்தம்", "ஒலி") -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                try {
                    when {
                        has(s, "mute", "silent", "அமைதி") -> {
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
                            r("Muted.", "ஒலி அணைக்கப்பட்டது.")
                        }
                        has(s, "max", "full", "அதிகபட்சம்") -> {
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), AudioManager.FLAG_SHOW_UI)
                            r("Volume at maximum.", "ஒலி அதிகபட்சம்.")
                        }
                        has(s, "down", "decrease", "lower", "குறை", "கம்மி") -> {
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                            r("Volume down.", "ஒலி குறைக்கப்பட்டது.")
                        }
                        has(s, "up", "increase", "raise", "louder", "கூட்டு", "அதிகம்") -> {
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                            r("Volume up.", "ஒலி கூட்டப்பட்டது.")
                        }
                        else -> r("Say volume up, down, max or mute.", "வால்யூம் கூட்டு, குறை, மேக்ஸ் அல்லது மியூட் என்று சொல்லுங்கள்.")
                    }
                } catch (e: Exception) {
                    r("I couldn't change the volume.", "ஒலியை மாற்ற முடியவில்லை.")
                }
            }
            // Timer
            has(s, "timer", "டைமர்") -> {
                val n = firstNumber(s)
                if (n == null || n <= 0) r("For how long? Say for example: timer 5 minutes.", "எவ்வளவு நேரம்? உதாரணம்: 5 நிமிடம் டைமர்.")
                else {
                    val unit = when {
                        has(s, "second", "sec", "வினாடி") -> 1
                        has(s, "hour", "மணி நேரம்", "மணிநேரம்") -> 3600
                        else -> 60
                    }
                    val i = Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, n * unit)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, "BRO")
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    if (start(ctx, i)) r("I asked the Clock app to start the timer.", "கடிகார ஆப்பிடம் டைமர் தொடங்கக் கேட்டுள்ளேன்.")
                    else r("The Clock app couldn't start the timer.", "டைமரைத் தொடங்க முடியவில்லை.")
                }
            }
            // Alarm
            has(s, "alarm", "அலாரம்", "alaram") -> {
                val m = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?").find(s)
                if (m == null) r("What time? Say for example: alarm at 7:30 am.", "எத்தனை மணிக்கு? உதாரணம்: காலை 7:30 அலாரம்.")
                else {
                    var h = m.groupValues[1].toInt()
                    val min = m.groupValues[2].ifEmpty { "0" }.toInt()
                    val mer = m.groupValues[3]
                    val pm = mer == "pm" || has(s, "மாலை", "இரவு", "evening", "night")
                    if (pm && h < 12) h += 12
                    if (mer == "am" && h == 12) h = 0
                    if (h !in 0..23 || min !in 0..59) r("That time isn't valid.", "அந்த நேரம் சரியில்லை.")
                    else {
                        val i = Intent(AlarmClock.ACTION_SET_ALARM)
                            .putExtra(AlarmClock.EXTRA_HOUR, h)
                            .putExtra(AlarmClock.EXTRA_MINUTES, min)
                            .putExtra(AlarmClock.EXTRA_MESSAGE, "BRO")
                            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                        val t = String.format(Locale.ENGLISH, "%02d:%02d", h, min)
                        if (start(ctx, i)) r("I asked the Clock app to set an alarm for $t.", "கடிகார ஆப்பிடம் $t அலாரம் அமைக்கக் கேட்டுள்ளேன்.")
                        else r("The Clock app couldn't set the alarm.", "அலாரம் அமைக்க முடியவில்லை.")
                    }
                }
            }
            // Settings pages (Android does not allow apps to toggle these directly)
            has(s, "wifi", "wi-fi", "வைஃபை", "வைபை") ->
                if (start(ctx, Intent(Settings.ACTION_WIFI_SETTINGS))) r("Opening Wi-Fi settings. Android needs you to toggle it.", "வைஃபை அமைப்புகளைத் திறக்கிறேன். ஆன்/ஆஃப் நீங்களே செய்ய வேண்டும்.")
                else r("Couldn't open Wi-Fi settings.", "வைஃபை அமைப்புகளைத் திறக்க முடியவில்லை.")
            has(s, "bluetooth", "ப்ளூடூத்", "புளூடூத்") ->
                if (start(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))) r("Opening Bluetooth settings.", "ப்ளூடூத் அமைப்புகளைத் திறக்கிறேன்.")
                else r("Couldn't open Bluetooth settings.", "ப்ளூடூத் அமைப்புகளைத் திறக்க முடியவில்லை.")
            // Open an installed app
            has(s, *openWords.toTypedArray()) -> {
                var q = s.split(" ").filter { it.isNotBlank() && it !in stopWords }.joinToString(" ")
                for ((k, v) in aliases) if (q.contains(k)) q = v
                if (q.isBlank()) r("Which app should I open?", "எந்த ஆப்பைத் திறக்க வேண்டும்?")
                else {
                    val app = AppIndex.find(ctx, q)
                    if (app == null) r("I couldn't find an app named $q.", "$q என்ற ஆப் கிடைக்கவில்லை.")
                    else if (AppIndex.launch(ctx, app.pkg)) r("Opening ${app.label}.", "${app.label} திறக்கிறேன்.")
                    else r("I couldn't open ${app.label}.", "${app.label}-ஐத் திறக்க முடியவில்லை.")
                }
            }
            has(s, "time", "நேரம்", "மணி", "neram") -> {
                val t = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date())
                r("It's $t.", "இப்போது நேரம் $t.")
            }
            has(s, "date", "today", "day", "தேதி", "இன்று", "indru", "inniku") -> {
                val d = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())
                r("Today is $d.", "இன்று $d.")
            }
            has(s, "battery", "charge", "பேட்டரி", "சார்ஜ்") -> {
                val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
                if (level < 0) r("I couldn't read the battery level.", "பேட்டரி அளவைப் படிக்க முடியவில்லை.")
                else {
                    val pct = level * 100 / scale
                    r("Battery is at $pct percent.", "பேட்டரி $pct சதவீதம் உள்ளது.")
                }
            }
            has(s, "how are you", "epadi irukka", "எப்படி இருக்க") ->
                r("I'm doing great. How can I help?", "நான் நலமாக இருக்கிறேன். எப்படி உதவலாம்?")
            has(s, "who are you", "your name", "yaar", "நீ யார்", "பெயர்", "peru") ->
                r("I'm BRO, your private assistant.", "நான் BRO, உங்கள் தனிப்பட்ட உதவியாளர்.")
            has(s, "thank", "நன்றி", "nandri") -> r("Anytime!", "எப்போதும் உதவுவேன்!")
            has(s, "hello", "hey", "vanakkam", "வணக்கம்") || s == "hi" ->
                r("Hello! I'm BRO. What do you need?", "வணக்கம்! நான் BRO. என்ன வேண்டும்?")
            else -> r("I don't know that command yet.", "அந்தக் கட்டளை எனக்கு இன்னும் தெரியாது.")
        }
    }
}
