package com.privateai.bro

import android.content.Context
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.Typeface as ComposeTypeface

/** Free OFL fonts fetched at build time (Anton + Space Mono). Falls back to system fonts if missing. */
object Fonts {
    var display: FontFamily = FontFamily.SansSerif
    var mono: FontFamily = FontFamily.Monospace
    var monoBold: FontFamily = FontFamily.Monospace
    var displayLoaded = false
    var monoBoldLoaded = false
    var androidMono: android.graphics.Typeface = android.graphics.Typeface.MONOSPACE
    private var done = false

    private fun load(ctx: Context, name: String): android.graphics.Typeface? = try {
        android.graphics.Typeface.createFromAsset(ctx.assets, "fonts/$name")
    } catch (e: Exception) {
        null
    }

    fun init(ctx: Context) {
        if (done) return
        done = true
        load(ctx, "Anton-Regular.ttf")?.let { display = FontFamily(ComposeTypeface(it)); displayLoaded = true }
        load(ctx, "SpaceMono-Regular.ttf")?.let { mono = FontFamily(ComposeTypeface(it)); androidMono = it }
        load(ctx, "SpaceMono-Bold.ttf")?.let { monoBold = FontFamily(ComposeTypeface(it)); monoBoldLoaded = true }
    }
}
