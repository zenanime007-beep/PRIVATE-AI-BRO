package com.privateai.bro

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.content.ContextCompat

/**
 * Optional always-on listener (foreground service, visible notification, one-tap stop).
 * Audio stays in memory and is never saved or uploaded. It is released while BRO is busy.
 */
class ListenService : Service() {

    companion object {
        @Volatile var running = false
        private const val CHANNEL = "bro_listen"
        private const val ACTION_STOP = "com.privateai.bro.LISTEN_STOP"

        fun sync(ctx: Context) {
            val want = (Prefs.wakeOn || Prefs.clapOn) &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            ctx.stopService(Intent(ctx, ListenService::class.java))
            if (want) ctx.startForegroundService(Intent(ctx, ListenService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ListenService::class.java))
        }
    }

    @Volatile private var alive = false
    private var worker: Thread? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Assistant.init(this)
        startForeground(3, notification())
        alive = true
        running = true
        main.post { Metrics.listening = true }
        worker = Thread({ loop() }, "bro-listen").also {
            it.priority = Thread.MIN_PRIORITY
            it.start()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.wakeOn = false
            Prefs.clapOn = false
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "BRO listening", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ListenService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val what = when {
            Prefs.wakeOn && Prefs.clapOn -> "Listening for \"Hey Bro\" and a double clap"
            Prefs.wakeOn -> "Listening for \"Hey Bro\" / \"Hello Bro\""
            else -> "Listening for a double clap"
        }
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("BRO microphone is ON")
            .setContentText("$what. Audio is not saved or uploaded.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Turn off", stop)
            .setOngoing(true)
            .build()
    }

    private fun loop() {
        var engine: WakeEngine? = null
        if (Prefs.wakeOn) {
            val e = WakeFactory.create()
            val err = e.load(this)
            if (err == null) engine = e else main.post { Metrics.wakeError = err }
        }
        val clap = ClapDetector()
        val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val buf = ShortArray(2048)

        while (alive) {
            if (Assistant.state != OrbState.IDLE) { sleep(150); continue }
            val rec = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8192)
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); sleep(1500); continue }
            rec.startRecording()
            var fired = false
            while (alive && !fired && Assistant.state == OrbState.IDLE) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0) continue
                if (Prefs.clapOn && clap.feed(buf, n)) {
                    fired = true
                    main.post { Metrics.lastWake = "DOUBLE CLAP" }
                    break
                }
                val hit = engine?.feed(buf, n)
                if (hit != null && accept(hit)) fired = true
            }
            try { rec.stop() } catch (e: Exception) {}
            rec.release()
            if (fired) {
                main.post { Assistant.activate() }
                sleep(700)
            }
        }
        engine?.close()
    }

    /** Phrase check, then (if enabled) owner-voice check. Voice alone never unlocks private data. */
    private fun accept(hit: WakeHit): Boolean {
        val t = hit.text.lowercase()
        if (!t.contains("hey bro") && !t.contains("hello bro")) return false
        main.post { Assistant.external(OrbState.VERIFYING) }
        if (Prefs.speakerLock && VoiceProfile.exists()) {
            val d = hit.speaker?.let { VoiceProfile.distance(it) }
            main.post { Metrics.lastDist = d ?: -1f; Metrics.lastWake = t }
            if (d == null || d > Prefs.spkThreshold) {
                main.postDelayed({ Assistant.external(OrbState.IDLE) }, 500)
                return false
            }
        } else {
            main.post { Metrics.lastWake = t }
        }
        return true
    }

    private fun sleep(ms: Long) {
        try { Thread.sleep(ms) } catch (e: InterruptedException) {}
    }

    override fun onDestroy() {
        alive = false
        running = false
        worker?.interrupt()
        main.post { Metrics.listening = false }
        super.onDestroy()
    }
}
