package com.privateai.bro

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        Fonts.init(this)
        Assistant.init(this)
        OrbRenderer.theme = if (Gate.has(Feature.ORB_THEME)) Prefs.orbTheme else 0
        handleIntent(intent)
        setContent { App(this) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        val t = i?.getIntExtra("tab", -1) ?: -1
        if (t in 0..7) {
            Nav.tab = t
            Nav.lensMode = i?.getIntExtra("mode", 0) ?: 0
        }
    }
}

private enum class Stage { SPLASH, LOCK, SETUP, APP }

@Composable
private fun App(act: FragmentActivity) {
    var stage by remember { mutableStateOf(Stage.SPLASH) }
    LaunchedEffect(Unit) {
        delay(1700)
        stage = if (Prefs.ownerSet) Stage.LOCK else Stage.SETUP
    }
    when (stage) {
        Stage.SPLASH -> Splash()
        Stage.LOCK -> Lock(act) { stage = Stage.APP }
        Stage.SETUP -> Setup { Session.mark(); stage = Stage.APP }
        Stage.APP -> Shell(act)
    }
}

// ---------- helpers ----------

internal fun granted(ctx: Context, perm: String) =
    ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

private fun biometricAvailable(ctx: Context): Boolean =
    Build.VERSION.SDK_INT >= 30 &&
        BiometricManager.from(ctx).canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        ) == BiometricManager.BIOMETRIC_SUCCESS

private fun promptBiometric(act: FragmentActivity, onOk: () -> Unit) {
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle("PRIVATE AI")
        .setSubtitle("Confirm it's you")
        .setAllowedAuthenticators(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )
        .build()
    val prompt = BiometricPrompt(
        act, ContextCompat.getMainExecutor(act),
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                onOk()
            }
        }
    )
    prompt.authenticate(info)
}

@Composable
private fun resumeTick(): Int {
    var tick by remember { mutableStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}

@Composable
internal fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Sig.Ink, unfocusedBorderColor = Sig.Ink,
    focusedTextColor = Sig.Ink, unfocusedTextColor = Sig.Ink,
    cursorColor = Sig.Ink, focusedLabelColor = Sig.Ink, unfocusedLabelColor = Sig.Mute
)

@Composable
private fun StageOrb(sizeDp: Int, interactive: Boolean = false, onTap: (() -> Unit)? = null) {
    AndroidView(
        factory = { ctx ->
            OrbView(ctx).apply {
                this.interactive = interactive
                if (onTap != null) setOnClickListener { onTap() }
            }
        },
        update = { it.orbState = Assistant.state; it.audioLevel = Assistant.audioLevel },
        modifier = Modifier.size(sizeDp.dp)
    )
}

// ---------- splash / setup / lock ----------

@Composable
private fun Splash() {
    Column(Modifier.fillMaxSize().background(Sig.Pink).padding(24.dp)) {
        Mono("PRIVATE AI", 13.sp, Sig.Ink, bold = true)
        Spacer(Modifier.height(8.dp))
        Display("BRO.", 150.sp, Color.White)
        Spacer(Modifier.height(16.dp))
        Box(Modifier.fillMaxWidth().border(2.dp, Sig.Ink).background(Sig.Stage), contentAlignment = Alignment.Center) {
            StageOrb(260)
        }
        Spacer(Modifier.height(16.dp))
        Mono("YOUR VOICE. YOUR INTELLIGENCE. YOUR PRIVATE WORLD.", 12.sp, Sig.Ink, bold = true)
    }
}

@Composable
private fun Setup(onDone: () -> Unit) {
    var step by remember { mutableStateOf(0) }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val micL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { step = 2 }
    val fieldStyle = TextStyle(fontFamily = Fonts.mono, fontSize = 20.sp)

    Column(Modifier.fillMaxSize().background(Sig.Paper).verticalScroll(rememberScrollState()).padding(24.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Mono("OWNER SETUP", 12.sp, Sig.Ink, bold = true)
            Mono("0${step + 1}/03", 12.sp, Sig.Red, bold = true)
        }
        Spacer(Modifier.height(12.dp))
        when (step) {
            0 -> {
                Display("MAKE A PIN.", 76.sp, Sig.Red)
                Spacer(Modifier.height(12.dp))
                Mono("4 TO 6 DIGITS. STORED ONLY ON THIS PHONE AS A SALTED HASH.", 12.sp, Sig.Ink)
                Spacer(Modifier.height(20.dp))
                OutlinedTextField(
                    value = pin, onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) pin = it },
                    label = { Mono("PIN", 12.sp, Sig.Mute) }, singleLine = true, textStyle = fieldStyle,
                    shape = androidx.compose.ui.graphics.RectangleShape, colors = fieldColors(),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = pin2, onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) pin2 = it },
                    label = { Mono("CONFIRM PIN", 12.sp, Sig.Mute) }, singleLine = true, textStyle = fieldStyle,
                    shape = androidx.compose.ui.graphics.RectangleShape, colors = fieldColors(),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth()
                )
                if (err.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Mono(err, 12.sp, Sig.Red, bold = true)
                }
                Spacer(Modifier.height(20.dp))
                BlockButton("SAVE PIN", Modifier.fillMaxWidth()) {
                    when {
                        pin.length < 4 -> err = "PIN NEEDS 4+ DIGITS."
                        pin != pin2 -> err = "PINS DON'T MATCH."
                        else -> { Prefs.setPin(pin); err = ""; step = 1 }
                    }
                }
            }
            1 -> {
                Display("GIVE IT EARS.", 76.sp, Sig.Red)
                Spacer(Modifier.height(12.dp))
                Mono("BRO LISTENS ONLY AFTER YOU TAP THE ORB. THIS APP DOES NOT RECORD OR STORE AUDIO.", 12.sp, Sig.Ink)
                Spacer(Modifier.height(20.dp))
                BlockButton("ALLOW MICROPHONE", Modifier.fillMaxWidth()) { micL.launch(Manifest.permission.RECORD_AUDIO) }
                Spacer(Modifier.height(12.dp))
                BlockButton("SKIP FOR NOW", Modifier.fillMaxWidth(), Color.White, Sig.Ink) { step = 2 }
            }
            else -> {
                Display("YOU'RE IN.", 76.sp, Sig.Red)
                Spacer(Modifier.height(20.dp))
                BlockButton("OPEN BRO", Modifier.fillMaxWidth(), onClick = onDone)
            }
        }
    }
}

@Composable
private fun Lock(act: FragmentActivity, onOk: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var confirmWipe by remember { mutableStateOf(false) }
    val bioOk = remember { Prefs.biometricOn && biometricAvailable(act) }
    val unlocked = { Session.mark(); Prefs.failCount = 0; onOk() }
    LaunchedEffect(Unit) { if (bioOk) promptBiometric(act, unlocked) }

    fun tryPin() {
        val now = System.currentTimeMillis()
        if (now < Prefs.lockUntil) { err = "WAIT ${(Prefs.lockUntil - now) / 1000 + 1}S."; return }
        if (Prefs.verifyPin(pin)) { unlocked(); return }
        Prefs.failCount = Prefs.failCount + 1
        pin = ""
        err = "WRONG PIN."
        if (Prefs.failCount >= 5) {
            Prefs.lockUntil = now + 30_000L * (1 shl minOf(Prefs.failCount - 5, 6))
            err = "TOO MANY TRIES. LOCKED."
        }
    }

    Column(Modifier.fillMaxSize().background(Sig.Pink).verticalScroll(rememberScrollState()).padding(24.dp)) {
        Mono("PRIVATE AI · LOCKED", 12.sp, Sig.Ink, bold = true)
        Spacer(Modifier.height(8.dp))
        Display("WHO'S THIS?", 72.sp, Color.White)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            repeat(6) { i ->
                Box(
                    Modifier.size(16.dp).border(2.dp, Sig.Ink)
                        .background(if (i < pin.length) Sig.Ink else Color.Transparent)
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Mono(err, 12.sp, Sig.Ink, bold = true)
        Spacer(Modifier.height(12.dp))
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "DEL", "0", "GO")
        keys.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { k ->
                    HardCard(Modifier.weight(1f).padding(4.dp), Color.White, onClick = {
                        when (k) {
                            "DEL" -> pin = pin.dropLast(1)
                            "GO" -> tryPin()
                            else -> if (pin.length < 6) pin += k
                        }
                    }) {
                        Mono(k, 20.sp, Sig.Ink, Modifier.align(Alignment.Center), bold = true)
                    }
                }
            }
        }
        if (bioOk) {
            Spacer(Modifier.height(12.dp))
            BlockButton("USE FINGERPRINT", Modifier.fillMaxWidth()) { promptBiometric(act, unlocked) }
        }
        Spacer(Modifier.height(16.dp))
        BlockButton(
            if (confirmWipe) "TAP AGAIN: ERASE EVERYTHING" else "FORGOT PIN? ERASE ALL & RESET",
            Modifier.fillMaxWidth(), Sig.Ink, Sig.Acid
        ) {
            if (!confirmWipe) confirmWipe = true
            else {
                ListenService.stop(act)
                Prefs.wipeAll()
                Session.clear()
                act.recreate()
            }
        }
        Mono("ERASING DELETES THE PIN, MEMORY, VOICE PROFILE AND SETTINGS FROM THIS PHONE.", 10.sp, Sig.Ink)
    }
}

// ---------- shell ----------

@Composable
private fun Shell(act: FragmentActivity) {
    var tab by remember { mutableStateOf(0) }
    val st = Assistant.state
    val bg by animateColorAsState(bgFor(st), tween(220), label = "bg")
    val fg = fgFor(st)
    val head = if (st == OrbState.IDLE) Sig.Red else fg
    LaunchedEffect(Nav.tab) {
        if (Nav.tab >= 0) { tab = Nav.tab; Nav.tab = -1 }
    }
    // Hide private screens from screenshots and the recent-apps preview.
    DisposableEffect(tab) {
        val w = act.window
        if (tab == 4 || tab == 5 || tab == 6) w.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else w.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { }
    }
    Column(Modifier.fillMaxSize().background(bg)) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> HomeScreen(st, fg, head)
                1 -> LensScreen(fg, head)
                2 -> RoutinesScreen(fg, head)
                3 -> AppsScreen(fg, head)
                4 -> MemoryScreen(fg, head)
                5 -> WakeScreen(fg, head)
                6 -> AccessScreen(fg, head)
                else -> TuneScreen(act, fg, head)
            }
        }
        BottomBar(listOf("HOME", "LENS", "ROUTINE", "APPS", "MEMORY", "WAKE", "ACCESS", "TUNE"), tab) { tab = it }
    }
}

@Composable
private fun HomeScreen(st: OrbState, fg: Color, head: Color) {
    val ctx = LocalContext.current
    var overlayOn by remember { mutableStateOf(OrbService.running) }
    val micL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) Assistant.activate() }
    val notifL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    val status = when (st) {
        OrbState.IDLE -> "TAP THE ORB AND SPEAK"
        OrbState.WAKE -> "WAKING"
        OrbState.LISTENING -> "LISTENING…"
        OrbState.VERIFYING -> "VERIFYING…"
        OrbState.THINKING -> "THINKING…"
        OrbState.EXECUTING -> "WORKING…"
        OrbState.SPEAKING -> "SPEAKING…"
        OrbState.CONFIRM -> "CONFIRM?"
        OrbState.ERROR -> "SOMETHING WENT WRONG"
        OrbState.OFFLINE -> "OFFLINE"
        OrbState.LOCKED -> "LOCKED"
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Mono("PRIVATE AI / BRO", 12.sp, fg, bold = true)
            Mono("V0.4", 12.sp, head, bold = true)
        }
        Spacer(Modifier.height(8.dp))
        Display(wordFor(st), 84.sp, head)
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().border(2.dp, Sig.Ink).background(Sig.Stage), contentAlignment = Alignment.Center) {
            StageOrb(300, interactive = true) {
                if (!Assistant.hasMic()) micL.launch(Manifest.permission.RECORD_AUDIO) else Assistant.activate()
            }
            Tag("BRO DIRECTION · ORB 01", Modifier.align(Alignment.BottomStart).padding(10.dp))
            Mono("TAP · DRAG TO TILT", 10.sp, Color.White, Modifier.align(Alignment.TopEnd).padding(10.dp))
        }
        Spacer(Modifier.height(10.dp))
        Mono(status, 12.sp, fg, bold = true)
        Spacer(Modifier.height(14.dp))
        HardCard(Modifier.fillMaxWidth(), Color.White) {
            Column {
                Mono("YOU SAID", 10.sp, Sig.Red, bold = true)
                Mono(Assistant.heard.ifEmpty { "—" }, 15.sp, Sig.Ink)
            }
        }
        Spacer(Modifier.height(10.dp))
        HardCard(Modifier.fillMaxWidth(), Sig.Ink) {
            Column {
                Mono("BRO", 10.sp, Sig.Acid, bold = true)
                Mono(Assistant.reply.ifEmpty { "—" }, 15.sp, Color.White)
            }
        }
        Spacer(Modifier.height(16.dp))
        BlockButton(
            if (overlayOn) "FLOATING ORB: ON · TAP TO TURN OFF" else "FLOATING ORB: OFF · TAP TO TURN ON",
            Modifier.fillMaxWidth()
        ) {
            if (overlayOn) {
                ctx.stopService(Intent(ctx, OrbService::class.java))
                overlayOn = false
            } else if (!Settings.canDrawOverlays(ctx)) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
            } else {
                if (Build.VERSION.SDK_INT >= 33) notifL.launch(Manifest.permission.POST_NOTIFICATIONS)
                ctx.startForegroundService(Intent(ctx, OrbService::class.java))
                overlayOn = true
            }
        }
        Spacer(Modifier.height(4.dp))
        Mono("IF IT STOPS ON VIVO: ALLOW AUTO-START AND UNRESTRICTED BATTERY FOR THIS APP.", 10.sp, fg)
        Spacer(Modifier.height(24.dp))
        Display("TRY SAYING", 44.sp, head)
        Spacer(Modifier.height(6.dp))
        val rows = listOf(
            "open whatsapp" to "opens it",
            "torch on" to "light",
            "timer 5 minutes" to "clock app",
            "call amma" to "dialer ready",
            "remember my exam is friday" to "saved",
            "scan this qr" to "camera tab",
            "start study mode" to "routine runs"
        )
        Box(Modifier.fillMaxWidth().height(2.dp).background(Sig.Ink))
        rows.forEachIndexed { i, (a, b) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Mono("0${i + 1}", 14.sp, head, bold = true)
                Spacer(Modifier.width(10.dp))
                Mono(a, 12.sp, fg, Modifier.weight(1f).padding(end = 6.dp))
                Mono("→", 14.sp, Sig.Red, bold = true)
                Spacer(Modifier.width(6.dp))
                Mono(b, 12.sp, fg, bold = true)
            }
            Box(Modifier.fillMaxWidth().height(2.dp).background(Sig.Ink))
        }
        Spacer(Modifier.height(8.dp))
        Mono("தமிழ்: வாட்ஸ்அப் திற · டார்ச் போடு · வால்யூம் கூட்டு", 12.sp, fg)
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun AppsScreen(fg: Color, head: Color) {
    val ctx = LocalContext.current
    val apps = remember { AppIndex.list(ctx) }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
        Display("APPS", 84.sp, head)
        Mono("${apps.size} INSTALLED · TAP TO OPEN", 12.sp, fg, bold = true)
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(2.dp).background(Sig.Ink))
        LazyColumn {
            items(apps, key = { it.pkg }) { a ->
                val icon = remember(a.pkg) {
                    runCatching { ctx.packageManager.getApplicationIcon(a.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
                }
                Row(
                    Modifier.fillMaxWidth().clickable { AppIndex.launch(ctx, a.pkg) }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (icon != null) Image(bitmap = icon, contentDescription = a.label, modifier = Modifier.size(42.dp))
                    else Box(Modifier.size(42.dp))
                    Spacer(Modifier.width(14.dp))
                    Mono(a.label, 14.sp, fg, bold = true)
                }
                Box(Modifier.fillMaxWidth().height(2.dp).background(Sig.Ink))
            }
        }
    }
}

@Composable
private fun MemoryScreen(fg: Color, head: Color) {
    var version by remember { mutableStateOf(0) }
    val items = remember(version, Assistant.reply) { MemoryStore.all() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        Display("MEMORY", 84.sp, head)
        Mono("${items.size}/${Gate.maxMemory()} SAVED · ENCRYPTED ON THIS PHONE · NEVER UPLOADED", 12.sp, fg, bold = true)
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(2.dp).background(Sig.Ink))
        if (items.isEmpty()) {
            Spacer(Modifier.height(12.dp))
            Mono("EMPTY. SAY: \"REMEMBER MY EXAM IS ON FRIDAY\"", 12.sp, fg)
        }
        items.forEachIndexed { i, text ->
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Mono("0${i + 1}".takeLast(2), 13.sp, head, bold = true)
                Spacer(Modifier.width(10.dp))
                Mono(text, 13.sp, fg, Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                BlockButton("X", Modifier.width(52.dp), Sig.Ink, Sig.Acid) { MemoryStore.remove(i); version++ }
            }
            Box(Modifier.fillMaxWidth().height(2.dp).background(Sig.Ink))
        }
        if (items.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            BlockButton("CLEAR ALL MEMORY", Modifier.fillMaxWidth(), Sig.Red, Color.White) { MemoryStore.clear(); version++ }
        }
    }
}

@Composable
private fun AccessScreen(fg: Color, head: Color) {
    val ctx = LocalContext.current
    val tick = resumeTick()
    var bump by remember { mutableStateOf(0) }
    val micL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { bump++ }
    val contactsL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { bump++ }
    val notifL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { bump++ }
    val camL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { bump++ }

    @Composable
    fun PermRow(name: String, why: String, on: Boolean, action: () -> Unit) {
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Mono(name, 14.sp, fg, bold = true)
                Mono(why, 11.sp, fg)
            }
            Spacer(Modifier.width(8.dp))
            if (on) Tag("ON", bg = Sig.Ink, fg = Sig.Acid)
            else BlockButton("GRANT", Modifier.width(96.dp), Sig.Ink, Sig.Acid, action)
        }
        Box(Modifier.fillMaxWidth().height(2.dp).background(Sig.Ink))
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        Display("ACCESS", 84.sp, head)
        Mono("EACH PERMISSION, WHY IT EXISTS. ASKED ONLY WHEN YOU TAP.", 12.sp, fg, bold = true)
        Spacer(Modifier.height(12.dp))
        LevelCard(fg, head)
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(2.dp).background(Sig.Ink))
        key(tick, bump) {
            PermRow("MICROPHONE", "Hear your command after you tap the orb.", granted(ctx, Manifest.permission.RECORD_AUDIO)) {
                micL.launch(Manifest.permission.RECORD_AUDIO)
            }
            PermRow("CONTACTS", "Find a name to call or message. Never uploaded.", granted(ctx, Manifest.permission.READ_CONTACTS)) {
                contactsL.launch(Manifest.permission.READ_CONTACTS)
            }
            PermRow("CAMERA", "Only when you open the camera in LENS. Nothing is saved.", granted(ctx, Manifest.permission.CAMERA)) {
                camL.launch(Manifest.permission.CAMERA)
            }
            PermRow("DISPLAY OVER APPS", "Show the floating orb and top pill.", Settings.canDrawOverlays(ctx)) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
            }
            PermRow(
                "NOTIFICATIONS", "Show the 'orb is on' notice while the orb runs.",
                Build.VERSION.SDK_INT < 33 || granted(ctx, Manifest.permission.POST_NOTIFICATIONS)
            ) { if (Build.VERSION.SDK_INT >= 33) notifL.launch(Manifest.permission.POST_NOTIFICATIONS) }
        }
        Spacer(Modifier.height(16.dp))
        Mono("YOU CAN REVOKE ANY OF THESE IN ANDROID SETTINGS → APPS → PRIVATE AI.", 11.sp, fg)
    }
}

@Composable
private fun LabeledSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, fg: Color,
    fmt: (Float) -> String, onChange: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Mono(label, 12.sp, fg, bold = true)
            Mono(fmt(value), 12.sp, fg, bold = true)
        }
        Slider(
            value = value, onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Sig.Ink, activeTrackColor = Sig.Ink, inactiveTrackColor = Sig.Ink.copy(alpha = .25f)
            )
        )
    }
}

@Composable
private fun TuneScreen(act: FragmentActivity, fg: Color, head: Color) {
    var lang by remember { mutableStateOf(Prefs.langTag) }
    var orbDp by remember { mutableStateOf(Prefs.orbDp.toFloat()) }
    var rate by remember { mutableStateOf(Prefs.speechRate) }
    var pitch by remember { mutableStateOf(Prefs.pitch) }
    var bio by remember { mutableStateOf(Prefs.biometricOn) }
    var oldPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var pinMsg by remember { mutableStateOf("") }
    var theme by remember { mutableStateOf(Prefs.orbTheme) }
    var report by remember { mutableStateOf("") }
    val bioAvail = remember { biometricAvailable(act) }
    val fieldStyle = TextStyle(fontFamily = Fonts.mono, fontSize = 16.sp)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        Display("TUNE", 84.sp, head)
        Spacer(Modifier.height(8.dp))

        Mono("LANGUAGE", 12.sp, fg, bold = true)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth()) {
            BlockButton("ENGLISH", Modifier.weight(1f).padding(end = 6.dp),
                if (lang == "en-IN") Sig.Ink else Color.White, if (lang == "en-IN") Sig.Acid else Sig.Ink) {
                lang = "en-IN"; Prefs.langTag = lang
            }
            BlockButton("தமிழ்", Modifier.weight(1f),
                if (lang == "ta-IN") Sig.Ink else Color.White, if (lang == "ta-IN") Sig.Acid else Sig.Ink) {
                lang = "ta-IN"; Prefs.langTag = lang
            }
        }
        Spacer(Modifier.height(16.dp))
        if (Gate.has(Feature.ORB_SIZE)) {
            LabeledSlider("ORB SIZE (RESTART ORB TO APPLY)", orbDp, 56f..112f, fg, { "${it.toInt()}DP" }) {
                orbDp = it; Prefs.orbDp = it.toInt()
            }
        } else LockedRow("ORB SIZE", fg)
        LabeledSlider("VOICE SPEED", rate, 0.6f..1.6f, fg, { "%.1fx".format(it) }) { rate = it; Prefs.speechRate = it }
        if (Gate.has(Feature.VOICE_PITCH)) {
            LabeledSlider("VOICE PITCH", pitch, 0.6f..1.6f, fg, { "%.1fx".format(it) }) { pitch = it; Prefs.pitch = it }
        } else LockedRow("VOICE PITCH", fg)
        BlockButton("TEST VOICE", Modifier.fillMaxWidth()) {
            Assistant.say(
                if (lang == "ta-IN") "வணக்கம், நான் BRO." else "Hello, I'm BRO.",
                lang == "ta-IN"
            )
        }

        Spacer(Modifier.height(16.dp))
        Mono("ORB LOOK", 12.sp, fg, bold = true)
        Spacer(Modifier.height(6.dp))
        if (Gate.has(Feature.ORB_THEME)) {
            Row(Modifier.fillMaxWidth()) {
                listOf("BRO", "EMBER", "TOXIC", "MONO").forEachIndexed { i, label ->
                    BlockButton(
                        label, Modifier.weight(1f).padding(end = 4.dp),
                        if (theme == i) Sig.Ink else Color.White, if (theme == i) Sig.Acid else Sig.Ink
                    ) { theme = i; Prefs.orbTheme = i; OrbRenderer.theme = i }
                }
            }
        } else LockedRow("ORB COLOUR THEMES", fg)

        Spacer(Modifier.height(24.dp))
        Display("SECURITY", 44.sp, head)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Mono("FINGERPRINT UNLOCK", 13.sp, fg, bold = true)
                Mono(if (bioAvail) "Uses Android's own fingerprint or screen-lock prompt." else "Not available on this phone or Android version.", 11.sp, fg)
            }
            Switch(
                checked = bio && bioAvail, enabled = bioAvail,
                onCheckedChange = { bio = it; Prefs.biometricOn = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Sig.Acid, checkedTrackColor = Sig.Ink,
                    uncheckedThumbColor = Sig.Ink, uncheckedTrackColor = Sig.Paper, uncheckedBorderColor = Sig.Ink
                )
            )
        }
        Spacer(Modifier.height(12.dp))
        Mono("CHANGE PIN", 12.sp, fg, bold = true)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = oldPin, onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) oldPin = it },
            label = { Mono("OLD PIN", 11.sp, Sig.Mute) }, singleLine = true, textStyle = fieldStyle,
            shape = androidx.compose.ui.graphics.RectangleShape, colors = fieldColors(),
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = newPin, onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) newPin = it },
            label = { Mono("NEW PIN", 11.sp, Sig.Mute) }, singleLine = true, textStyle = fieldStyle,
            shape = androidx.compose.ui.graphics.RectangleShape, colors = fieldColors(),
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        BlockButton("UPDATE PIN", Modifier.fillMaxWidth(), Color.White, Sig.Ink) {
            pinMsg = when {
                !Prefs.verifyPin(oldPin) -> "OLD PIN IS WRONG."
                newPin.length < 4 -> "NEW PIN NEEDS 4+ DIGITS."
                else -> { Prefs.setPin(newPin); oldPin = ""; newPin = ""; "PIN CHANGED." }
            }
        }
        if (pinMsg.isNotEmpty()) Mono(pinMsg, 12.sp, fg, bold = true)

        Spacer(Modifier.height(24.dp))
        Display("DIAGNOSTICS", 44.sp, head)
        Spacer(Modifier.height(6.dp))
        BlockButton("CHECK VOICE SUPPORT", Modifier.fillMaxWidth()) { report = Assistant.voiceReport() }
        if (report.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            HardCard(Modifier.fillMaxWidth(), Color.White) { Mono(report, 11.sp, Sig.Ink) }
        }
        Spacer(Modifier.height(10.dp))
        MetricsCard()

        Spacer(Modifier.height(24.dp))
        Display("ABOUT", 44.sp, head)
        Spacer(Modifier.height(6.dp))
        Mono("PRIVATE AI · BRO — VERSION 0.6.0", 12.sp, fg, bold = true)
        Mono("CREATED BY ANANTH.", 12.sp, fg, bold = true)
        Mono("LOCAL-FIRST. NO ACCOUNT, NO ANALYTICS, NO ADS. ANDROID'S OWN SPEECH SERVICE MAY USE THE NETWORK.", 11.sp, fg)
        Spacer(Modifier.height(6.dp))
        Mono("NOT BUILT: TRANSLATION · NOTIFICATION READING · SMART HOME · OFFLINE TAMIL SPEECH (DEPENDS ON YOUR PHONE).", 11.sp, fg)
        Mono("EVERYTHING HERE IS UNTESTED ON A REAL PHONE UNTIL YOU TRY IT. REPORT ANYTHING THAT BREAKS.", 11.sp, fg, bold = true)
        Spacer(Modifier.height(16.dp))
    }
}
