package com.privateai.bro

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Personal memory, encrypted with an Android Keystore AES-GCM key. Never leaves the phone. */
object MemoryStore {
    private const val ALIAS = "bro_memory_key"
    private const val MAX = 100

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return gen.generateKey()
    }

    private fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val out = c.iv + c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }

    private fun decrypt(blob: String): String {
        val b = Base64.decode(blob, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b, 0, 12))
        return String(c.doFinal(b, 12, b.size - 12), Charsets.UTF_8)
    }

    fun all(): List<String> {
        val blob = Prefs.memoryBlob ?: return emptyList()
        return try {
            val arr = JSONArray(decrypt(blob))
            List(arr.length()) { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(text: String): Boolean {
        return try {
            val list = (all() + text.trim()).takeLast(minOf(MAX, Gate.maxMemory()))
            Prefs.memoryBlob = encrypt(JSONArray(list).toString())
            true
        } catch (e: Exception) {
            false
        }
    }

    fun remove(index: Int): Boolean {
        return try {
            val list = all().toMutableList()
            if (index !in list.indices) return false
            list.removeAt(index)
            Prefs.memoryBlob = if (list.isEmpty()) null else encrypt(JSONArray(list).toString())
            true
        } catch (e: Exception) {
            false
        }
    }

    fun clear() {
        Prefs.memoryBlob = null
    }
}
