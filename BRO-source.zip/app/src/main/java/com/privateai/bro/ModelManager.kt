package com.privateai.bro

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.BufferedInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads the free Vosk models once, when the user taps Download. Nothing is sent to the server. */
object ModelManager {
    private const val WAKE_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private const val SPK_URL = "https://alphacephei.com/vosk/models/vosk-model-spk-0.4.zip"
    private val main = Handler(Looper.getMainLooper())

    var status by mutableStateOf("")
    var busy by mutableStateOf(false)

    private fun root(ctx: Context) = File(ctx.filesDir, "models")
    fun wakeModelDir(ctx: Context) = File(root(ctx), "vosk-model-small-en-us-0.15")
    fun spkModelDir(ctx: Context) = File(root(ctx), "vosk-model-spk-0.4")
    fun wakeReady(ctx: Context) = wakeModelDir(ctx).exists()
    fun spkReady(ctx: Context) = spkModelDir(ctx).exists()

    private fun post(msg: String) { main.post { status = msg } }

    fun download(ctx: Context) {
        if (busy) return
        busy = true
        val app = ctx.applicationContext
        Thread {
            try {
                if (!wakeReady(app)) fetch(app, WAKE_URL, wakeModelDir(app), "WAKE MODEL")
                if (!spkReady(app)) fetch(app, SPK_URL, spkModelDir(app), "VOICE MODEL")
                post("DONE. BOTH MODELS READY.")
            } catch (e: Exception) {
                post("FAILED: ${e.message ?: "network error"}. TRY AGAIN ON WI-FI.")
            } finally {
                main.post { busy = false }
            }
        }.start()
    }

    private fun fetch(ctx: Context, url: String, finalDir: File, label: String) {
        val root = root(ctx).apply { mkdirs() }
        val rootPath = root.canonicalPath
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        if (conn.responseCode != 200) throw IllegalStateException("server said ${conn.responseCode}")
        val total = conn.contentLengthLong
        var read = 0L
        var lastPct = -1
        try {
            ZipInputStream(BufferedInputStream(conn.inputStream)).use { zin ->
                var e = zin.nextEntry
                val buf = ByteArray(16384)
                while (e != null) {
                    val out = File(root, e.name)
                    if (!out.canonicalPath.startsWith(rootPath)) throw SecurityException("bad zip entry")
                    if (e.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { o ->
                            while (true) {
                                val n = zin.read(buf)
                                if (n < 0) break
                                o.write(buf, 0, n)
                                read += n
                                if (total > 0) {
                                    val pct = (read * 100 / total).toInt().coerceAtMost(99)
                                    if (pct != lastPct) { lastPct = pct; post("DOWNLOADING $label $pct%") }
                                }
                            }
                        }
                    }
                    e = zin.nextEntry
                }
            }
        } catch (ex: Exception) {
            finalDir.deleteRecursively()
            throw ex
        }
        if (!finalDir.exists()) throw IllegalStateException("model folder missing after unzip")
    }
}
