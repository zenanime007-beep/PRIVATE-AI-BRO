package com.privateai.bro

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** The BRO orb: dark glass sphere, soft violet/blue blobs, crisp additive light blades, bright core. */
object OrbRenderer {
    private const val TAU = (2 * PI).toFloat()
    private const val DEG = 57.29578f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val add = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD) }
    private val addLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
    }
    private val path = Path()
    private val clip = Path()
    private val rect = RectF()

    // base angle, wobble, speed, length, width, colour index, depth
    private val blades = arrayOf(
        floatArrayOf(-1.5708f, .25f, .9f, .80f, .075f, 2f, .9f),
        floatArrayOf(1.0f, .3f, .7f, .72f, .11f, 0f, .7f),
        floatArrayOf(3.1416f, .18f, .6f, .86f, .15f, 2f, .5f),
        floatArrayOf(-.62f, .25f, .8f, .88f, .19f, 0f, .4f),
        floatArrayOf(2.45f, .3f, .75f, .7f, .16f, 1f, .6f),
        floatArrayOf(.05f, .2f, 1.1f, .62f, .07f, 2f, .8f),
        floatArrayOf(1.9f, .25f, .95f, .55f, .09f, 3f, .3f)
    )

    private val NORMAL = intArrayOf(0xFF397BFF.toInt(), 0xFF8257FF.toInt(), 0xFF64DFFF.toInt(), 0xFF5B6CFF.toInt())
    private val AMBER = intArrayOf(0xFFFF9A3D.toInt(), 0xFFFFC27A.toInt(), 0xFFFFE3C2.toInt(), 0xFFFF7A1A.toInt())
    private val RED = intArrayOf(0xFFE24B4A.toInt(), 0xFFFF8A3D.toInt(), 0xFFFFC27A.toInt(), 0xFFFF6A5C.toInt())
    private val GREY = intArrayOf(0xFF8A90A6.toInt(), 0xFFB4B8C8.toInt(), 0xFFD9DDE8.toInt(), 0xFF6A6F86.toInt())

    private val EMBER = intArrayOf(0xFFFF7A1A.toInt(), 0xFFFF3B1F.toInt(), 0xFFFFC27A.toInt(), 0xFFFF9A3D.toInt())
    private val TOXIC = intArrayOf(0xFFD4FF3A.toInt(), 0xFF3DFFB0.toInt(), 0xFF64DFFF.toInt(), 0xFF9BFF5B.toInt())
    private val MONO = intArrayOf(0xFFFFFFFF.toInt(), 0xFF9299AE.toInt(), 0xFFDDE1EE.toInt(), 0xFF6A6F86.toInt())
    private val THEMES = arrayOf(NORMAL, EMBER, TOXIC, MONO)

    /** 0 BRO, 1 EMBER, 2 TOXIC, 3 MONO. Premium/Owner can change it. */
    @Volatile var theme = 0

    fun palette(s: OrbState): IntArray = when (s) {
        OrbState.CONFIRM -> AMBER
        OrbState.ERROR -> RED
        OrbState.OFFLINE, OrbState.LOCKED -> GREY
        else -> THEMES[theme.coerceIn(0, 3)]
    }

    fun speed(s: OrbState): Float = when (s) {
        OrbState.IDLE -> .5f
        OrbState.WAKE -> 1.4f
        OrbState.LISTENING -> .9f
        OrbState.VERIFYING -> 1.4f
        OrbState.THINKING -> 2f
        OrbState.EXECUTING -> 1.6f
        OrbState.SPEAKING -> 1f
        OrbState.CONFIRM -> .7f
        OrbState.ERROR -> .6f
        OrbState.OFFLINE -> .2f
        OrbState.LOCKED -> .1f
    }

    fun baseEnergy(s: OrbState): Float = when (s) {
        OrbState.IDLE -> .12f
        OrbState.WAKE -> .6f
        OrbState.LISTENING -> .45f
        OrbState.VERIFYING -> .3f
        OrbState.THINKING -> .3f
        OrbState.EXECUTING -> .4f
        OrbState.SPEAKING -> .6f
        OrbState.CONFIRM -> .3f
        OrbState.ERROR -> .15f
        OrbState.OFFLINE -> .05f
        OrbState.LOCKED -> .05f
    }

    private fun a(c: Int, al: Float): Int = (c and 0x00FFFFFF) or ((al.coerceIn(0f, 1f) * 255).toInt() shl 24)

    private fun lens(len: Float, w: Float) {
        path.reset()
        path.moveTo(0f, 0f)
        path.quadTo(len * .5f, -w * 1.6f, len, 0f)
        path.quadTo(len * .5f, w * 1.6f, 0f, 0f)
    }

    private fun blob(cx: Float, cy: Float, r: Float, t: Float, seed: Float) {
        path.reset()
        for (k in 0..64) {
            val th = k / 64f * TAU
            val rr = r * (1f + .07f * sin(3f * th + t * .8f + seed) + .05f * sin(5f * th - t * 1.1f + seed * 2f) + .03f * sin(2f * th + t * .5f))
            val x = cx + cos(th) * rr
            val y = cy + sin(th) * rr
            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
    }

    fun draw(c: Canvas, cx0: Float, cy: Float, r: Float, t: Float, st: OrbState, en: Float, tx: Float, ty: Float) {
        val pal = palette(st)
        val sp = speed(st)
        val burst = when (st) {
            OrbState.WAKE -> 1f + .2f * abs(sin(t * 8f))
            OrbState.ERROR -> .55f
            else -> 1f
        }
        val cx = if (st == OrbState.ERROR) cx0 + sin(t * 34f) * r * .012f else cx0

        fill.style = Paint.Style.FILL
        fill.shader = RadialGradient(
            cx, cy, r * 1.8f,
            intArrayOf(a(pal[1], .3f + .28f * en), a(pal[1], 0f)), floatArrayOf(.33f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r * 1.8f, fill)

        fill.shader = null
        fill.color = Color.argb(70, 30, 35, 90)
        c.drawCircle(cx - r * .05f + tx * r * .03f, cy + r * .03f, r * 1.08f, fill)
        line.shader = null
        line.color = Color.argb(70, 140, 165, 255)
        line.strokeWidth = max(1f, r * .012f)
        c.drawCircle(cx - r * .05f + tx * r * .03f, cy + r * .03f, r * 1.08f, line)

        fill.shader = RadialGradient(
            cx - r * .2f, cy - r * .25f, r * 1.2f,
            intArrayOf(0xFF0F1440.toInt(), 0xFF02030A.toInt()), null, Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r, fill)

        c.save()
        clip.reset()
        clip.addCircle(cx, cy, r * .99f, Path.Direction.CW)
        c.clipPath(clip)

        fill.shader = RadialGradient(
            cx - r * .1f, cy, r * .7f,
            intArrayOf(a(pal[1], .8f), a(0xFF3A1A9E.toInt(), .5f)), null, Shader.TileMode.CLAMP
        )
        blob(cx - r * .12f + tx * r * .05f, cy + r * .05f + ty * r * .05f, r * .62f * (1f + .05f * en), t, 0f)
        c.drawPath(path, fill)
        fill.shader = RadialGradient(
            cx + r * .2f, cy + r * .1f, r * .45f,
            intArrayOf(a(pal[0], .7f), a(0xFF1B2A9A.toInt(), .4f)), null, Shader.TileMode.CLAMP
        )
        blob(cx + r * .18f + tx * r * .09f, cy + r * .1f + ty * r * .09f, r * .4f, t, 2.1f)
        c.drawPath(path, fill)
        fill.shader = null

        add.shader = null
        add.color = Color.argb(97, 190, 230, 255)
        for (i in 0 until 16) {
            val ha = i * TAU / 16f + t * .1f * sp
            val hl = r * (.45f + .4f * abs(sin(i * 1.3f + t * .8f))) * burst
            c.save()
            c.translate(cx, cy)
            c.rotate(ha * DEG)
            lens(hl, r * .012f)
            c.drawPath(path, add)
            c.restore()
        }

        for (i in blades.indices) {
            val b = blades[i]
            val col = pal[b[5].toInt()]
            val swirl = if (st == OrbState.THINKING) t * 1.5f * (if (i % 2 == 1) -1f else 1f) else 0f
            val ang = b[0] + sin(t * b[2] * sp + i * 1.7f) * b[1] + t * .05f + swirl
            val len = r * b[3] * (1f + .18f * en) * burst
            val w = r * b[4] * (1f + .9f * en * (.5f + .5f * sin(t * 4f + i)))
            c.save()
            c.translate(cx + tx * r * .14f * b[6], cy + ty * r * .14f * b[6])
            c.rotate(ang * DEG)
            lens(len, w)
            add.shader = LinearGradient(
                0f, 0f, len, 0f,
                intArrayOf(Color.argb(242, 255, 255, 255), a(col, .9f), a(col, .45f)),
                floatArrayOf(0f, .25f, 1f), Shader.TileMode.CLAMP
            )
            c.drawPath(path, add)
            line.shader = null
            line.color = Color.argb(100, 255, 255, 255)
            line.strokeWidth = max(1f, r * .008f)
            c.drawPath(path, line)
            lens(len * 1.06f, w * .22f)
            add.shader = null
            add.color = Color.argb(140, 255, 255, 255)
            c.drawPath(path, add)
            c.restore()
        }
        add.shader = null

        val coreR = r * (.42f + .14f * en)
        add.shader = RadialGradient(
            cx, cy, coreR,
            intArrayOf(Color.WHITE, a(pal[2], .6f), a(pal[0], 0f)), floatArrayOf(0f, .3f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, coreR, add)
        add.shader = null

        if (st == OrbState.LISTENING || st == OrbState.WAKE) {
            for (i in 0..2) {
                val p = (t * .8f + i / 3f) % 1f
                addLine.shader = null
                addLine.color = a(pal[2], (1f - p) * .35f)
                addLine.strokeWidth = r * .014f
                c.drawCircle(cx, cy, r * (.3f + .7f * p), addLine)
            }
        }
        c.restore()

        fill.shader = RadialGradient(
            cx, cy, r,
            intArrayOf(a(pal[2], 0f), a(pal[0], .14f), a(pal[2], .5f)), floatArrayOf(.72f, .82f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r, fill)
        fill.shader = null

        rect.set(cx - r * .985f, cy - r * .985f, cx + r * .985f, cy + r * .985f)
        addLine.shader = null
        addLine.color = a(pal[2], .7f)
        addLine.strokeWidth = r * .03f
        c.drawArc(rect, 120f, 92f, false, addLine)
        addLine.color = a(pal[1], .6f)
        addLine.strokeWidth = r * .025f
        c.drawArc(rect, 17f, 52f, false, addLine)
        if (st == OrbState.WAKE) {
            rect.set(cx - r * 1.04f, cy - r * 1.04f, cx + r * 1.04f, cy + r * 1.04f)
            addLine.color = Color.argb(242, 210, 240, 255)
            addLine.strokeWidth = r * .04f
            c.drawArc(rect, t * 6f * DEG, 57f, false, addLine)
        }

        line.shader = LinearGradient(
            cx - r, cy - r, cx + r, cy + r,
            intArrayOf(pal[2], pal[0], pal[1]), null, Shader.TileMode.CLAMP
        )
        line.strokeWidth = max(1f, r * .016f)
        c.drawCircle(cx, cy, r, line)
        line.shader = null

        c.save()
        c.translate(cx - r * .32f, cy - r * .55f)
        c.rotate(-26f)
        c.scale(1f, .34f)
        fill.shader = RadialGradient(
            0f, 0f, r * .4f,
            intArrayOf(Color.argb(89, 255, 255, 255), Color.argb(0, 255, 255, 255)), null, Shader.TileMode.CLAMP
        )
        c.drawCircle(0f, 0f, r * .4f, fill)
        c.restore()
        fill.shader = null
    }
}
