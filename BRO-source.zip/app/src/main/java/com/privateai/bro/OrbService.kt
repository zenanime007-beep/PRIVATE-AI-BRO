package com.privateai.bro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import kotlin.math.abs

/** Floating orb + top pill overlay. Needs the "display over other apps" permission granted by the user. */
class OrbService : Service() {

    companion object {
        @Volatile var running = false
        private const val CHANNEL = "bro_orb"
        private const val ACTION_STOP = "com.privateai.bro.STOP"
    }

    private var wm: WindowManager? = null
    private var orb: OrbView? = null
    private var pill: PillView? = null

    private val stateListener: () -> Unit = {
        val s = Assistant.state
        orb?.orbState = s
        orb?.audioLevel = Assistant.audioLevel
        pill?.let {
            it.orbState = s
            it.visibility = if (s == OrbState.IDLE) View.GONE else View.VISIBLE
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Fonts.init(this)
        Assistant.init(this)
        startForeground(1, buildNotification())
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        val manager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = manager
        addPill(manager)
        addOrb(manager)
        Assistant.listeners.add(stateListener)
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "BRO floating orb", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OrbService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("BRO orb is ON")
            .setContentText("Tap the orb to talk. The microphone is used only after you tap.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
            .setOngoing(true)
            .build()
    }

    private fun addPill(manager: WindowManager) {
        val d = resources.displayMetrics.density
        val lp = WindowManager.LayoutParams(
            (230 * d).toInt(), (52 * d).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (6 * d).toInt()
        }
        val v = PillView(this)
        v.visibility = View.GONE
        manager.addView(v, lp)
        pill = v
    }

    private fun addOrb(manager: WindowManager) {
        val dm = resources.displayMetrics
        val size = (Prefs.orbDp * dm.density).toInt()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (Prefs.orbX >= 0) Prefs.orbX else (dm.widthPixels - size) / 2
            y = if (Prefs.orbY >= 0) Prefs.orbY else (dm.heightPixels * 0.78f).toInt()
        }
        val view = OrbView(this)
        view.orbState = Assistant.state
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        var moved = false
        view.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y; downX = e.rawX; downY = e.rawY; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = (startX + dx).toInt()
                        lp.y = (startY + dy).toInt()
                        manager.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) Prefs.saveOrb(lp.x, lp.y) else Assistant.activate()
                    true
                }
                else -> false
            }
        }
        manager.addView(view, lp)
        orb = view
    }

    override fun onDestroy() {
        Assistant.listeners.remove(stateListener)
        orb?.let { runCatching { wm?.removeView(it) } }
        pill?.let { runCatching { wm?.removeView(it) } }
        orb = null
        pill = null
        running = false
        super.onDestroy()
    }
}
