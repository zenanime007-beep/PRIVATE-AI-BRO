package com.privateai.bro

enum class OrbState {
    IDLE, WAKE, LISTENING, VERIFYING, THINKING, SPEAKING,
    EXECUTING, CONFIRM, ERROR, OFFLINE, LOCKED
}
