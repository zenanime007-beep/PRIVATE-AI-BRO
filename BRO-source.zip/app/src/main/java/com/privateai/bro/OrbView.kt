package com.privateai.bro

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** View wrapper for the orb. Use interactive = true in the app to tilt it by touch. */
class OrbView(context: Context) : View(context) {

    var orbState: OrbState = OrbState.IDLE
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var interactive = false
    /** Live voice amplitude supplied by Assistant; zero outside listening. */
    var audioLevel: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            if (orbState == OrbState.LISTENING) invalidate()
        }

    private val t0 = System.nanoTime()
    private var energy = .12f
    private var tx = 0f
    private var ty = 0f
    private var ttx = 0f
    private var tty = 0f
    private var dragging = false
    private var moved = false
    private var downX = 0f
    private var downY = 0f
    private var frame = 0
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            frame++
            if (orbState != OrbState.IDLE || frame % 2 == 0) invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val t = (System.nanoTime() - t0) / 1_000_000_000f
        var target = OrbRenderer.baseEnergy(orbState)
        if (orbState == OrbState.SPEAKING) target += .3f * abs(sin(t * 7f) * sin(t * 3.1f))
        if (orbState == OrbState.LISTENING) target += .10f + audioLevel.coerceIn(0f, 1f) * .48f + .06f * abs(sin(t * 3.2f))
        energy += (target - energy) * .12f
        if (!dragging) {
            ttx = sin(t * .5f) * .6f
            tty = cos(t * .4f) * .4f
        }
        tx += (ttx - tx) * .1f
        ty += (tty - ty) * .1f
        val r = min(width, height) / 2f * .54f
        OrbRenderer.draw(canvas, width / 2f, height / 2f, r, t, orbState, energy, tx, ty)
    }

    private fun tilt(e: MotionEvent) {
        ttx = ((e.x / width) - .5f).times(2.4f).coerceIn(-1f, 1f)
        tty = ((e.y / height) - .5f).times(2.4f).coerceIn(-1f, 1f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!interactive) return super.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true; moved = false; downX = e.x; downY = e.y
                parent?.requestDisallowInterceptTouchEvent(true)
                tilt(e)
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(e.x - downX) > slop || abs(e.y - downY) > slop) moved = true
                tilt(e)
            }
            MotionEvent.ACTION_UP -> {
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
                if (!moved) performClick()
            }
            MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()
}
