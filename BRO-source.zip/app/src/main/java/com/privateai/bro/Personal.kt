package com.privateai.bro

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/** Memory, contacts (call/SMS/WhatsApp prepared for your final tap), YouTube search, maps. */
object Personal {

    private fun has(s: String, vararg keys: String) = keys.any { s.contains(it) }

    private val callStop = setOf(
        "call", "dial", "to", "please", "bro", "pannu", "பண்ணு", "பண்ணுங்க", "கால்", "அழை", "அழைக்க",
        "phone", "போன்", "podu", "போடு", "ku", "கு"
    )
    private val msgStop = setOf(
        "send", "message", "sms", "msg", "whatsapp", "a", "to", "please", "bro", "மெசேஜ்", "மெசேஜை",
        "அனுப்பு", "வாட்ஸ்அப்", "pannu", "பண்ணு", "text"
    )
    private val ytStop = setOf(
        "youtube", "யூடியூப்", "யூட்யூப்", "play", "search", "on", "in", "for", "to", "the", "a", "song",
        "video", "please", "bro", "பாடு", "தேடு", "பாட்டு", "pannu", "பண்ணு", "போடு", "podu"
    )
    private val navStop = setOf(
        "navigate", "directions", "direction", "to", "nearby", "show", "me", "please", "bro", "வழி",
        "வழிகாட்டு", "the", "a", "way", "for", "find"
    )
    private val memTrig = setOf(
        "remember", "save", "bro", "please", "நினைவில்", "வை", "ninaivil", "vai", "ஞாபகம்", "வச்சுக்கோ"
    )
    private val suffixes = listOf("வுக்கு", "க்கு", "ுக்கு", "கு")

    private fun hasContactsPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun findContact(ctx: Context, name: String): Pair<String, String>? {
        val candidates = listOf(name) + suffixes.filter { name.endsWith(it) && name.length > it.length }.map { name.removeSuffix(it) }
        for (n in candidates) {
            val c = ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                arrayOf("%$n%"), null
            )
            c?.use { if (it.moveToFirst()) return it.getString(0) to it.getString(1) }
        }
        return null
    }

    private fun start(ctx: Context, i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    fun handle(ctx: Context, s: String, t: List<String>, ta: Boolean): Reply? {
        fun r(en: String, tm: String) = Reply(if (ta) tm else en, ta)
        fun locked() = r("Open the BRO app and unlock it first.", "முதலில் BRO ஆப்பைத் திறந்து unlock செய்யுங்கள்.")

        // Camera and screen tools open in the app; the camera and screen capture always need your tap.
        fun lens(mode: Int, en: String, tm: String): Reply {
            val i = Intent(ctx, MainActivity::class.java).putExtra("tab", 1).putExtra("mode", mode)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            return if (start(ctx, i)) r(en, tm) else r("I couldn't open the app.", "ஆப்பைத் திறக்க முடியவில்லை.")
        }
        if (has(s, "scan", "qr code", "barcode", "ஸ்கேன்")) return lens(0, "Opening the camera tab. Tap open camera, then capture.", "கேமரா பகுதியைத் திறக்கிறேன். Open camera, பிறகு capture தட்டுங்கள்.")
        if (has(s, "read my screen", "read the screen", "screen read", "ஸ்கிரீன்")) return lens(0, "Opening the screen reader. Tap read my screen.", "ஸ்கிரீன் ரீடரைத் திறக்கிறேன். Read my screen தட்டுங்கள்.")
        if (has(s, "read this", "read text", "படி")) return lens(1, "Opening the camera tab in read-text mode.", "கேமரா பகுதியை text mode-ல் திறக்கிறேன்.")
        if (has(s, "what is this", "identify", "என்ன இது")) return lens(2, "Opening the camera tab in what-is-it mode.", "கேமரா பகுதியைத் திறக்கிறேன்.")

        // Routines: "start study mode"
        val routine = RoutineStore.all().firstOrNull { s.contains(it.name.lowercase()) && has(s, "mode", "routine", "start", "மோட்") }
        if (routine != null) {
            RoutineStore.run(ctx, routine)
            return r("Starting ${routine.name} mode.", "${routine.name} மோடைத் தொடங்குகிறேன்.")
        }

        // Memory: forget, recall, remember (order matters)
        if (has(s, "forget everything", "clear memory", "delete memory", "மறந்துவிடு", "நினைவகத்தை அழி")) {
            if (!Session.recent()) return locked()
            MemoryStore.clear()
            return r("Memory cleared.", "நினைவகம் அழிக்கப்பட்டது.")
        }
        if (has(s, "what do you remember", "what did i tell", "recall", "my memories", "நினைவில் என்ன", "என்ன சொன்னேன்")) {
            if (!Session.recent()) return locked()
            val items = MemoryStore.all()
            return if (items.isEmpty()) r("I have nothing saved yet.", "இன்னும் எதுவும் சேமிக்கவில்லை.")
            else {
                val txt = items.takeLast(5).joinToString("; ")
                r("You asked me to remember: $txt", "நீங்கள் சொன்னவை: $txt")
            }
        }
        if (has(s, "remember", "save this", "நினைவில் வை", "ஞாபகம்", "ninaivil vai")) {
            var body = t.filter { it !in memTrig }
            if (body.firstOrNull() == "that") body = body.drop(1)
            val text = body.joinToString(" ")
            if (text.isBlank()) return r("What should I remember?", "எதை நினைவில் வைக்க வேண்டும்?")
            return if (MemoryStore.add(text)) r("Saved: $text", "சேமித்தேன்: $text")
            else r("I couldn't save that.", "சேமிக்க முடியவில்லை.")
        }

        // Call: prepares the dialer, you press the call button
        if (t.any { it == "call" || it == "dial" || it == "கால்" || it == "அழை" || it == "அழைக்க" }) {
            val name = t.filter { it !in callStop }.joinToString(" ")
            if (name.isBlank()) return r("Who should I call?", "யாரை அழைக்க வேண்டும்?")
            if (!hasContactsPermission(ctx)) return r("I need the contacts permission. Open the app and tap Allow contacts.", "காண்டாக்ட்ஸ் அனுமதி தேவை. ஆப்பைத் திறந்து அனுமதி கொடுங்கள்.")
            val c = findContact(ctx, name) ?: return r("I couldn't find $name in your contacts.", "$name உங்கள் காண்டாக்ட்ஸில் கிடைக்கவில்லை.")
            return if (start(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(c.second)))))
                r("Dialer ready for ${c.first}. Tap call to confirm.", "${c.first}-க்கு டயலர் தயார். அழைக்க கால் பட்டனைத் தட்டுங்கள்.")
            else r("I couldn't open the dialer.", "டயலரைத் திறக்க முடியவில்லை.")
        }

        // WhatsApp / SMS message: prepared, you press send
        val wa = t.any { it == "whatsapp" || it == "வாட்ஸ்அப்" }
        val msgWord = t.any { it in setOf("message", "sms", "msg", "மெசேஜ்", "மெசேஜை") }
        if (msgWord || (wa && has(s, "saying", "என்று"))) {
            val markers = listOf(" saying ", " that says ", " says ", " என்று ")
            var namePart = s
            var body = ""
            for (m in markers) {
                val idx = s.indexOf(m)
                if (idx >= 0) {
                    namePart = s.substring(0, idx)
                    body = s.substring(idx + m.length).trim()
                    break
                }
            }
            val name = namePart.split(Regex("\\s+")).filter { it.isNotBlank() && it !in msgStop }.joinToString(" ")
            if (name.isBlank()) return r("Who is the message for?", "யாருக்கு மெசேஜ்?")
            if (!hasContactsPermission(ctx)) return r("I need the contacts permission. Open the app and tap Allow contacts.", "காண்டாக்ட்ஸ் அனுமதி தேவை. ஆப்பைத் திறந்து அனுமதி கொடுங்கள்.")
            val c = findContact(ctx, name) ?: return r("I couldn't find $name in your contacts.", "$name உங்கள் காண்டாக்ட்ஸில் கிடைக்கவில்லை.")
            val ok = if (wa) {
                var digits = c.second.filter { it.isDigit() }
                if (digits.length == 10) digits = "91$digits"
                start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits?text=" + Uri.encode(body))))
            } else {
                start(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(c.second))).putExtra("sms_body", body))
            }
            return if (ok) r("Message to ${c.first} is ready. Check it and tap send.", "${c.first}-க்கு மெசேஜ் தயார். சரிபார்த்து அனுப்பு பட்டனைத் தட்டுங்கள்.")
            else r("I couldn't open the messaging app.", "மெசேஜ் ஆப்பைத் திறக்க முடியவில்லை.")
        }

        // YouTube search
        if (has(s, "youtube", "யூடியூப்", "யூட்யூப்") && has(s, "play", "search", "தேடு", "பாடு", "song", "video", "பாட்டு")) {
            val q = t.filter { it !in ytStop }.joinToString(" ")
            if (q.isBlank()) return r("What should I search on YouTube?", "யூடியூப்பில் எதைத் தேட வேண்டும்?")
            val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
            val yt = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.youtube".replace("google.youtube", "google.android.youtube"))
            val ok = start(ctx, yt) || start(ctx, Intent(Intent.ACTION_VIEW, uri))
            return if (ok) r("Searching YouTube for $q.", "யூடியூப்பில் $q தேடுகிறேன்.")
            else r("I couldn't open YouTube.", "யூடியூப்பைத் திறக்க முடியவில்லை.")
        }

        // Maps
        if (t.any { it in setOf("navigate", "directions", "direction", "nearby", "வழி", "வழிகாட்டு") }) {
            val q = t.filter { it !in navStop }.joinToString(" ")
            if (q.isBlank()) return r("Where to?", "எங்கே செல்ல வேண்டும்?")
            val nearby = t.contains("nearby")
            val enc = Uri.encode(q)
            val ok = if (nearby) start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$enc")))
            else start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$enc")))
                || start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$enc")))
            return if (ok) r("Opening maps for $q.", "$q-க்கு மேப்ஸ் திறக்கிறேன்.")
            else r("I couldn't open a maps app.", "மேப்ஸ் ஆப்பைத் திறக்க முடியவில்லை.")
        }
        return null
    }
}
