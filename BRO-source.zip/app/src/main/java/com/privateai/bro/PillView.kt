package com.privateai.bro

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.sin

/** Top-of-screen pill that appears while BRO is active (wake, listening, thinking, speaking). */
class PillView(context: Context) : View(context) {

    var orbState: OrbState = OrbState.IDLE

    private val d = resources.displayMetrics.density
    private val t0 = System.nanoTime()
    private var pw = 56f * d
    private var energy = .1f
    private val rect = RectF()
    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
        color = Color.argb(120, 100, 140, 255)
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 11f * d
        typeface = Fonts.androidMono
        letterSpacing = .08f
    }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (visibility == VISIBLE) animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) {
            if (isAttachedToWindow && !animator.isStarted) animator.start()
        } else {
            animator.cancel()
        }
    }

    private fun label(): String = when (orbState) {
        OrbState.WAKE -> "WAKE"
        OrbState.LISTENING -> "LISTENING"
        OrbState.VERIFYING -> "VERIFYING"
        OrbState.THINKING -> "THINKING"
        OrbState.SPEAKING -> "SPEAKING"
        OrbState.EXECUTING -> "WORKING"
        OrbState.CONFIRM -> "CONFIRM?"
        OrbState.ERROR -> "ERROR"
        OrbState.OFFLINE -> "OFFLINE"
        OrbState.LOCKED -> "LOCKED"
        OrbState.IDLE -> ""
    }

    override fun onDraw(canvas: Canvas) {
        val t = (System.nanoTime() - t0) / 1_000_000_000f
        var target = OrbRenderer.baseEnergy(orbState)
        if (orbState == OrbState.SPEAKING) target += .3f * abs(sin(t * 7f) * sin(t * 3.1f))
        if (orbState == OrbState.LISTENING) target += .32f * abs(sin(t * 5f) * sin(t * 2.3f))
        energy += (target - energy) * .12f

        val h = 40f * d
        val top = (height - h) / 2f
        pw += (width - 4f * d - pw) * .16f
        val left = (width - pw) / 2f
        rect.set(left, top, left + pw, top + h)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, body)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, edge)

        OrbRenderer.draw(canvas, left + 22f * d, height / 2f, 11f * d, t, orbState, energy, 0f, 0f)

        if (pw > 120f * d) {
            val a = (((pw - 120f * d) / (40f * d)).coerceIn(0f, 1f) * 255).toInt()
            canvas.drawText(label(), left + 44f * d, height / 2f + 4f * d, text.apply { alpha = a })
            for (k in 0 until 5) {
                val bh = (4f + energy * 26f * abs(sin(t * 6f + k * .9f))) * d
                bar.color = if (k % 2 == 1) Color.argb(a, 130, 87, 255) else Color.argb(a, 100, 223, 255)
                val bx = left + pw - 74f * d + k * 12f * d
                canvas.drawRoundRect(bx, height / 2f - bh / 2f, bx + 5f * d, height / 2f + bh / 2f, 2f * d, 2f * d, bar)
            }
        }
    }
}
