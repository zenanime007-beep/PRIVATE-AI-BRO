package com.privateai.bro

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        if (!::sp.isInitialized) sp = ctx.applicationContext.getSharedPreferences("bro", Context.MODE_PRIVATE)
    }

    var memoryBlob: String?
        get() = sp.getString("mem", null)
        set(v) = if (v == null) sp.edit().remove("mem").apply() else sp.edit().putString("mem", v).apply()

    var biometricOn: Boolean
        get() = sp.getBoolean("bio", false)
        set(v) = sp.edit().putBoolean("bio", v).apply()

    var orbDp: Int
        get() = sp.getInt("orb_dp", 76)
        set(v) = sp.edit().putInt("orb_dp", v).apply()

    var speechRate: Float
        get() = sp.getFloat("rate", 1f)
        set(v) = sp.edit().putFloat("rate", v).apply()

    var pitch: Float
        get() = sp.getFloat("pitch", 1f)
        set(v) = sp.edit().putFloat("pitch", v).apply()

    var wakeOn: Boolean
        get() = sp.getBoolean("wake_on", false)
        set(v) = sp.edit().putBoolean("wake_on", v).apply()

    var clapOn: Boolean
        get() = sp.getBoolean("clap_on", false)
        set(v) = sp.edit().putBoolean("clap_on", v).apply()

    var speakerLock: Boolean
        get() = sp.getBoolean("spk_lock", false)
        set(v) = sp.edit().putBoolean("spk_lock", v).apply()

    var spkThreshold: Float
        get() = sp.getFloat("spk_thr", 0.45f)
        set(v) = sp.edit().putFloat("spk_thr", v).apply()

    var voiceBlob: String?
        get() = sp.getString("voice", null)
        set(v) = if (v == null) sp.edit().remove("voice").apply() else sp.edit().putString("voice", v).apply()

    var viewAs: String
        get() = sp.getString("view_as", "") ?: ""
        set(v) = sp.edit().putString("view_as", v).apply()

    var orbTheme: Int
        get() = sp.getInt("orb_theme", 0)
        set(v) = sp.edit().putInt("orb_theme", v).apply()

    var routines: String?
        get() = sp.getString("routines", null)
        set(v) = if (v == null) sp.edit().remove("routines").apply() else sp.edit().putString("routines", v).apply()

    var failCount: Int
        get() = sp.getInt("fails", 0)
        set(v) = sp.edit().putInt("fails", v).apply()

    var lockUntil: Long
        get() = sp.getLong("lock_until", 0L)
        set(v) = sp.edit().putLong("lock_until", v).apply()

    /** Erases every local setting, the PIN, memory and the voice profile (used by "forgot PIN"). */
    fun wipeAll() {
        sp.edit().clear().apply()
        Vault.deleteKey("bro_memory_key")
        Vault.deleteKey("bro_voice_key")
    }

    val ownerSet: Boolean get() = sp.contains("pin_hash")

    var langTag: String
        get() = sp.getString("lang", "en-IN") ?: "en-IN"
        set(v) = sp.edit().putString("lang", v).apply()

    var orbX: Int
        get() = sp.getInt("orb_x", -1)
        private set(v) = sp.edit().putInt("orb_x", v).apply()

    var orbY: Int
        get() = sp.getInt("orb_y", -1)
        private set(v) = sp.edit().putInt("orb_y", v).apply()

    fun saveOrb(x: Int, y: Int) {
        orbX = x
        orbY = y
    }

    private fun hash(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return Base64.encodeToString(f.generateSecret(spec).encoded, Base64.NO_WRAP)
    }

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        sp.edit()
            .putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", hash(pin, salt))
            .apply()
    }

    fun verifyPin(pin: String): Boolean {
        val saltB64 = sp.getString("pin_salt", null) ?: return false
        val stored = sp.getString("pin_hash", null) ?: return false
        val h = hash(pin, Base64.decode(saltB64, Base64.NO_WRAP))
        return MessageDigest.isEqual(h.toByteArray(), stored.toByteArray())
    }
}
