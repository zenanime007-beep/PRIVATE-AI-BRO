package com.privateai.bro

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject

class Routine(val name: String, val steps: List<String>)

/** Routines are lists of ordinary voice commands run one after another. Stored locally. */
object RoutineStore {
    private val main = Handler(Looper.getMainLooper())
    private val blocked = listOf("call", "dial", "message", "sms", "whatsapp", "forget", "clear memory")

    private fun defaults() = listOf(
        Routine("study", listOf("timer 25 minutes", "volume down")),
        Routine("workout", listOf("timer 30 minutes", "volume max")),
        Routine("sleep", listOf("torch off", "volume down"))
    )

    fun all(): List<Routine> {
        val raw = Prefs.routines ?: return defaults()
        return try {
            val a = JSONArray(raw)
            List(a.length()) {
                val o = a.getJSONObject(it)
                val st = o.getJSONArray("steps")
                Routine(o.getString("name"), List(st.length()) { i -> st.getString(i) })
            }
        } catch (e: Exception) {
            defaults()
        }
    }

    fun save(list: List<Routine>) {
        val a = JSONArray()
        list.forEach { r ->
            a.put(JSONObject().put("name", r.name).put("steps", JSONArray(r.steps)))
        }
        Prefs.routines = a.toString()
    }

    fun isBlocked(step: String): Boolean {
        val s = step.lowercase()
        return blocked.any { s.contains(it) }
    }

    /** Runs on the main thread, one step every 900 ms. Calls and messages are never run from a routine. */
    fun run(ctx: Context, r: Routine) {
        val app = ctx.applicationContext
        r.steps.forEachIndexed { i, step ->
            main.postDelayed({
                if (isBlocked(step)) {
                    Assistant.showResult("SKIPPED \"$step\": CALLS AND MESSAGES NEED YOU.", false)
                } else {
                    val rep = CommandEngine.process(app, step)
                    Assistant.showResult(rep.text, false)
                }
            }, i * 900L)
        }
        main.postDelayed({ Assistant.showResult("${r.name.uppercase()} DONE.", false) }, r.steps.size * 900L + 300)
    }
}
