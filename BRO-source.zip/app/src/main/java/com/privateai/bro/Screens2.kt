package com.privateai.bro

import android.Manifest
import android.content.Context
import android.os.Debug
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun SwitchRow(title: String, note: String, checked: Boolean, enabled: Boolean, fg: Color, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Mono(title, 13.sp, fg, bold = true)
            Mono(note, 11.sp, fg)
        }
        Switch(
            checked = checked, enabled = enabled, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Sig.Acid, checkedTrackColor = Sig.Ink,
                uncheckedThumbColor = Sig.Ink, uncheckedTrackColor = Sig.Paper, uncheckedBorderColor = Sig.Ink
            )
        )
    }
    Box2(fg)
}

@Composable
private fun Box2(fg: Color) {
    androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth().height(2.dp).background(Sig.Ink))
}

@Composable
fun LockedRow(label: String, fg: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Mono(label, 12.sp, fg, Modifier.weight(1f), bold = true)
        Tag("PREMIUM", bg = Sig.Ink, fg = Sig.Acid)
    }
}

@Composable
fun WakeScreen(fg: Color, head: Color) {
    val ctx = LocalContext.current
    var bump by remember { mutableStateOf(0) }
    var wakeOn by remember { mutableStateOf(Prefs.wakeOn) }
    var clapOn by remember { mutableStateOf(Prefs.clapOn) }
    var lock by remember { mutableStateOf(Prefs.speakerLock) }
    var thr by remember { mutableStateOf(Prefs.spkThreshold) }
    val micL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) ListenService.sync(ctx)
        bump++
    }
    val status = ModelManager.status
    val busy = ModelManager.busy
    val wakeReady = ModelManager.wakeReady(ctx)
    val spkReady = ModelManager.spkReady(ctx)
    val enrolled = VoiceProfile.exists()
    val micOk = granted(ctx, Manifest.permission.RECORD_AUDIO)
    val bumpRead = bump

    fun apply() { Prefs.wakeOn = wakeOn; Prefs.clapOn = clapOn; Prefs.speakerLock = lock; ListenService.sync(ctx) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        Display("WAKE", 84.sp, head)
        Mono("HEY BRO · HELLO BRO · DOUBLE CLAP · ONLY YOUR VOICE", 12.sp, fg, bold = true)
        Spacer(Modifier.height(10.dp))

        if (!BuildConfig.HAS_WAKE) {
            HardCard(Modifier.fillMaxWidth(), Color.White) {
                Mono("THIS BUILD HAS NO WAKE-WORD ENGINE. DOUBLE CLAP AND ORB TAP STILL WORK.", 12.sp, Sig.Ink, bold = true)
            }
            Spacer(Modifier.height(10.dp))
        } else {
            Display("MODELS", 40.sp, head)
            Mono(
                "ONE-TIME DOWNLOAD (ABOUT 55 MB) OF FREE OFFLINE MODELS FROM alphacephei.com. NOTHING OF YOURS IS SENT.",
                11.sp, fg
            )
            Spacer(Modifier.height(6.dp))
            Mono("WAKE MODEL: ${if (wakeReady) "READY" else "MISSING"}   VOICE MODEL: ${if (spkReady) "READY" else "MISSING"}", 12.sp, fg, bold = true)
            if (status.isNotEmpty()) Mono(status, 12.sp, fg)
            Spacer(Modifier.height(6.dp))
            if (!(wakeReady && spkReady)) {
                BlockButton(if (busy) "DOWNLOADING…" else "DOWNLOAD MODELS", Modifier.fillMaxWidth()) {
                    if (!busy) ModelManager.download(ctx)
                }
            }

            Spacer(Modifier.height(20.dp))
            Display("YOUR VOICE", 40.sp, head)
            Mono("SAY \"HEY BRO\" FIVE TIMES. ONLY A NUMBER FINGERPRINT IS SAVED, ENCRYPTED. NO AUDIO IS KEPT.", 11.sp, fg)
            Spacer(Modifier.height(6.dp))
            if (Enroller.progress.isNotEmpty()) Mono(Enroller.progress, 12.sp, fg, bold = true)
            Spacer(Modifier.height(6.dp))
            BlockButton(
                if (Enroller.running) "LISTENING… SAY HEY BRO" else if (enrolled) "RE-ENROLL MY VOICE" else "ENROLL MY VOICE",
                Modifier.fillMaxWidth()
            ) {
                if (Enroller.running) return@BlockButton
                if (!micOk) micL.launch(Manifest.permission.RECORD_AUDIO)
                else if (!(wakeReady && spkReady)) Enroller.progress = "DOWNLOAD THE MODELS FIRST."
                else Enroller.start(ctx) { bump++; ListenService.sync(ctx) }
            }
            if (enrolled) {
                Spacer(Modifier.height(8.dp))
                BlockButton("DELETE MY VOICE PROFILE", Modifier.fillMaxWidth(), Sig.Red, Color.White) {
                    VoiceProfile.delete(); lock = false; Prefs.speakerLock = false; Enroller.progress = "PROFILE DELETED."; bump++
                    ListenService.sync(ctx)
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Display("SWITCHES", 40.sp, head)
        if (BuildConfig.HAS_WAKE) {
            SwitchRow(
                "ALWAYS-ON HEY BRO / HELLO BRO",
                "KEEPS THE MIC OPEN IN THE BACKGROUND, WITH A NOTIFICATION. USES MORE BATTERY. AUDIO STAYS IN MEMORY ONLY.",
                wakeOn, wakeReady, fg
            ) { on ->
                if (on && !micOk) { micL.launch(Manifest.permission.RECORD_AUDIO) } else { wakeOn = on; apply() }
            }
        }
        SwitchRow(
            "DOUBLE CLAP",
            "TWO CLAPS WAKE BRO. LOUD NOISES CAN TRIGGER IT BY MISTAKE.",
            clapOn, true, fg
        ) { on ->
            if (on && !micOk) { micL.launch(Manifest.permission.RECORD_AUDIO) } else { clapOn = on; apply() }
        }
        if (BuildConfig.HAS_WAKE) {
            SwitchRow(
                "ONLY MY VOICE WAKES BRO",
                if (enrolled) "A DIFFERENT VOICE SAYING HEY BRO IS IGNORED." else "ENROLL YOUR VOICE FIRST.",
                lock, enrolled, fg
            ) { on -> lock = on; apply() }
            if (enrolled) {
                Column(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Mono("MATCH STRICTNESS", 12.sp, fg, bold = true)
                        Mono("%.2f".format(thr), 12.sp, fg, bold = true)
                    }
                    Slider(
                        value = thr, onValueChange = { thr = it; Prefs.spkThreshold = it }, valueRange = 0.2f..0.8f,
                        colors = SliderDefaults.colors(thumbColor = Sig.Ink, activeTrackColor = Sig.Ink, inactiveTrackColor = Sig.Ink.copy(alpha = .25f))
                    )
                    Mono("LOWER = STRICTER (MAY IGNORE YOU). HIGHER = LOOSER (MAY ACCEPT OTHERS). TUNE USING LAST DISTANCE BELOW.", 10.sp, fg)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        BlockButton("TURN ALL LISTENING OFF", Modifier.fillMaxWidth(), Sig.Red, Color.White) {
            wakeOn = false; clapOn = false; apply()
        }

        Spacer(Modifier.height(20.dp))
        Mono("LISTENING SERVICE: ${if (Metrics.listening) "ON" else "OFF"}", 12.sp, fg, bold = true)
        if (Metrics.lastWake.isNotEmpty()) Mono("LAST WAKE: ${Metrics.lastWake.uppercase()}", 11.sp, fg)
        if (Metrics.lastDist >= 0f) Mono("LAST VOICE DISTANCE: %.2f".format(Metrics.lastDist), 11.sp, fg)
        if (Metrics.wakeError.isNotEmpty()) Mono("WAKE ERROR: ${Metrics.wakeError.uppercase()}", 11.sp, fg)
        Spacer(Modifier.height(10.dp))
        Mono(
            "HONEST LIMITS: VOICE MATCHING IS NOT PERFECT. IT CAN MISS YOU OR ACCEPT A SIMILAR VOICE, AND A RECORDING OF YOU MAY FOOL IT. " +
                "PRIVATE THINGS STILL NEED YOUR PIN OR FINGERPRINT. ON VIVO, ALLOW AUTO-START AND UNRESTRICTED BATTERY OR THE SERVICE MAY BE KILLED.",
            10.sp, fg
        )
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun RoutinesScreen(fg: Color, head: Color) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(RoutineStore.all()) }
    var name by remember { mutableStateOf("") }
    var steps by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    val style = TextStyle(fontFamily = Fonts.mono, fontSize = 14.sp)

    fun persist(l: List<Routine>) { RoutineStore.save(l); list = l }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        Display("ROUTINES", 64.sp, head)
        Mono("A ROUTINE IS A LIST OF VOICE COMMANDS, RUN ONE BY ONE. SAY \"START STUDY MODE\".", 12.sp, fg, bold = true)
        Spacer(Modifier.height(8.dp))
        list.forEach { r ->
            HardCard(Modifier.fillMaxWidth().padding(vertical = 6.dp), Color.White) {
                Column {
                    Display(r.name, 34.sp, Sig.Ink)
                    r.steps.forEachIndexed { i, s ->
                        Mono("0${i + 1}  $s" + if (RoutineStore.isBlocked(s)) "  (WON'T RUN)" else "", 12.sp, Sig.Ink)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth()) {
                        BlockButton("RUN", Modifier.weight(1f).padding(end = 6.dp)) { RoutineStore.run(ctx, r) }
                        BlockButton("EDIT", Modifier.weight(1f).padding(end = 6.dp), Color.White, Sig.Ink) {
                            name = r.name; steps = r.steps.joinToString("\n")
                        }
                        BlockButton("DELETE", Modifier.weight(1f), Sig.Red, Color.White) {
                            persist(list.filter { it.name != r.name })
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Display("NEW / EDIT", 36.sp, head)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = name, onValueChange = { name = it.take(20) },
            label = { Mono("NAME (E.G. STUDY)", 11.sp, Sig.Mute) }, singleLine = true, textStyle = style,
            shape = RectangleShape, colors = fieldColors(), modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = steps, onValueChange = { steps = it },
            label = { Mono("ONE COMMAND PER LINE", 11.sp, Sig.Mute) }, minLines = 3, textStyle = style,
            shape = RectangleShape, colors = fieldColors(), modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions.Default
        )
        Spacer(Modifier.height(8.dp))
        BlockButton("SAVE ROUTINE", Modifier.fillMaxWidth()) {
            val n = name.trim().lowercase()
            val lines = steps.lines().map { it.trim() }.filter { it.isNotEmpty() }
            val exists = list.any { it.name == n }
            msg = when {
                n.isEmpty() -> "GIVE IT A NAME."
                lines.isEmpty() -> "ADD AT LEAST ONE COMMAND."
                !exists && list.size >= Gate.maxRoutines() -> "THIS LEVEL ALLOWS ${Gate.maxRoutines()} ROUTINES. PREMIUM AND OWNER GET MORE."
                else -> {
                    persist(list.filter { it.name != n } + Routine(n, lines))
                    name = ""; steps = ""
                    "SAVED."
                }
            }
        }
        if (msg.isNotEmpty()) Mono(msg, 12.sp, fg, bold = true)
        Spacer(Modifier.height(8.dp))
        Mono("CALLS, MESSAGES AND MEMORY-DELETE COMMANDS NEVER RUN FROM A ROUTINE.", 10.sp, fg)
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun LevelCard(fg: Color, head: Color) {
    var view by remember { mutableStateOf(Prefs.viewAs) }
    val level = Gate.level()
    Column(Modifier.fillMaxWidth()) {
        Display("LEVEL", 40.sp, head)
        Mono("YOU ARE: ${level.name}", 14.sp, fg, bold = true)
        Spacer(Modifier.height(6.dp))
        Mono("PREVIEW THE LOCKS (OWNER ONLY):", 11.sp, fg)
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth()) {
            listOf("OWNER" to "", "PREMIUM" to "PREMIUM", "FREE" to "FREE").forEach { (label, v) ->
                BlockButton(
                    label, Modifier.weight(1f).padding(end = 4.dp),
                    if (view == v) Sig.Ink else Color.White, if (view == v) Sig.Acid else Sig.Ink
                ) {
                    view = v; Prefs.viewAs = v
                    OrbRenderer.theme = if (Gate.has(Feature.ORB_THEME)) Prefs.orbTheme else 0
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Mono(
            "OWNER = WHOEVER SET UP THIS INSTALL. NO PAYMENT, NO ONLINE CHECK. THERE IS NO CODE OR HIDDEN SWITCH THAT UNLOCKS PREMIUM FOR SOMEONE ELSE.",
            10.sp, fg
        )
        Spacer(Modifier.height(14.dp))
    }
}

@Composable
fun MetricsCard() {
    val ctx = LocalContext.current
    val mi = Debug.MemoryInfo()
    Debug.getMemoryInfo(mi)
    val lines = listOf(
        "BUILD: WAKE=${BuildConfig.HAS_WAKE} LENS=${BuildConfig.HAS_INTEL}",
        "APP RAM (PSS): ${mi.totalPss / 1024} MB",
        "LAST COMMAND, END OF SPEECH → REPLY: ${if (Metrics.lastCmdMs >= 0) "${Metrics.lastCmdMs} MS" else "NOT MEASURED YET"}",
        "LAST WAKE: ${Metrics.lastWake.ifEmpty { "—" }.uppercase()}",
        "LAST VOICE DISTANCE: ${if (Metrics.lastDist >= 0f) "%.2f".format(Metrics.lastDist) else "—"}",
        "WAKE MODEL: ${if (ModelManager.wakeReady(ctx)) "READY" else "MISSING"}   VOICE PROFILE: ${if (VoiceProfile.exists()) "SAVED" else "NONE"}",
        "LISTENING SERVICE: ${if (Metrics.listening) "ON" else "OFF"}"
    )
    HardCard(Modifier.fillMaxWidth(), Color.White) {
        Column { lines.forEach { Mono(it, 11.sp, Sig.Ink) } }
    }
}
