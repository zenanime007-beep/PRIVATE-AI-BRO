package com.privateai.bro

import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Remembers when the owner last unlocked the app (gates private voice commands such as memory recall). */
object Session {
    @Volatile private var unlockedAt = 0L
    fun mark() { unlockedAt = SystemClock.elapsedRealtime() }
    fun recent(): Boolean = unlockedAt > 0 && SystemClock.elapsedRealtime() - unlockedAt < 10 * 60_000L
    fun clear() { unlockedAt = 0L }
}

/** Measured values shown in Diagnostics. Always written on the main thread. */
object Metrics {
    var lastDist by mutableStateOf(-1f)
    var lastCmdMs by mutableStateOf(-1L)
    var lastWake by mutableStateOf("")
    var wakeError by mutableStateOf("")
    var listening by mutableStateOf(false)
}

/** Lets voice commands ask the UI to open a tab (e.g. the camera). */
object Nav {
    var tab by mutableStateOf(-1)
    var lensMode by mutableStateOf(0)
}
