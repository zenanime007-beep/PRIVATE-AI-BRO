package com.privateai.bro

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** "Signal" palette: flat, loud, no gradients in the interface chrome. */
object Sig {
    val Paper = Color(0xFFF2EEE3)
    val Ink = Color(0xFF0B0B0C)
    val Pink = Color(0xFFFF2E88)
    val Red = Color(0xFFFF3B1F)
    val Acid = Color(0xFFD4FF3A)
    val Stage = Color(0xFF050507)
    val Grey = Color(0xFFCFCABB)
    val Mute = Color(0xFF6E6A5F)
}

fun bgFor(s: OrbState): Color = when (s) {
    OrbState.LISTENING, OrbState.WAKE -> Sig.Pink
    OrbState.THINKING, OrbState.EXECUTING, OrbState.VERIFYING -> Sig.Ink
    OrbState.SPEAKING -> Sig.Acid
    OrbState.CONFIRM, OrbState.ERROR -> Sig.Red
    OrbState.OFFLINE, OrbState.LOCKED -> Sig.Grey
    OrbState.IDLE -> Sig.Paper
}

fun fgFor(s: OrbState): Color = when (s) {
    OrbState.LISTENING, OrbState.WAKE, OrbState.THINKING, OrbState.EXECUTING,
    OrbState.VERIFYING, OrbState.CONFIRM, OrbState.ERROR -> Color.White
    else -> Sig.Ink
}

fun wordFor(s: OrbState): String = when (s) {
    OrbState.IDLE -> "HEY BRO."
    OrbState.WAKE -> "HERE."
    OrbState.LISTENING -> "GO ON."
    OrbState.VERIFYING -> "HOLD ON."
    OrbState.THINKING -> "HMM."
    OrbState.EXECUTING -> "ON IT."
    OrbState.SPEAKING -> "LISTEN."
    OrbState.CONFIRM -> "SURE?"
    OrbState.ERROR -> "NOPE."
    OrbState.OFFLINE -> "OFFLINE."
    OrbState.LOCKED -> "LOCKED."
}

@Composable
fun Display(text: String, size: TextUnit, color: Color, modifier: Modifier = Modifier) {
    Text(
        text = text.uppercase(),
        modifier = modifier,
        color = color,
        fontFamily = Fonts.display,
        fontWeight = if (Fonts.displayLoaded) FontWeight.Normal else FontWeight.Black,
        fontSize = size,
        lineHeight = size * 0.92f,
        letterSpacing = (-1).sp
    )
}

@Composable
fun Mono(text: String, size: TextUnit, color: Color, modifier: Modifier = Modifier, bold: Boolean = false) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontFamily = if (bold) Fonts.monoBold else Fonts.mono,
        fontWeight = if (bold && !Fonts.monoBoldLoaded) FontWeight.Bold else FontWeight.Normal,
        fontSize = size,
        lineHeight = size * 1.35f,
        letterSpacing = 0.3.sp
    )
}

@Composable
fun Tag(text: String, modifier: Modifier = Modifier, bg: Color = Sig.Red, fg: Color = Color.White) {
    Box(modifier.rotate(-2f).background(bg).padding(horizontal = 10.dp, vertical = 4.dp)) {
        Mono(text, 11.sp, fg, bold = true)
    }
}

@Composable
fun HardCard(
    modifier: Modifier = Modifier,
    bg: Color = Color.White,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val click = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
    Box(modifier.padding(end = 4.dp, bottom = 4.dp).then(click)) {
        Box(Modifier.matchParentSize().offset(4.dp, 4.dp).background(Sig.Ink))
        Box(Modifier.border(2.dp, Sig.Ink).background(bg).padding(12.dp), content = content)
    }
}

@Composable
fun BlockButton(
    label: String,
    modifier: Modifier = Modifier,
    bg: Color = Sig.Ink,
    fg: Color = Sig.Acid,
    onClick: () -> Unit
) {
    HardCard(modifier, bg, onClick) {
        Mono(label.uppercase(), 13.sp, fg, Modifier.align(Alignment.Center), bold = true)
    }
}

@Composable
fun BottomBar(tabs: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Sig.Ink).horizontalScroll(rememberScrollState())) {
        tabs.forEachIndexed { i, label ->
            Box(
                Modifier.width(92.dp)
                    .background(if (i == selected) Sig.Acid else Sig.Ink)
                    .clickable { onSelect(i) }
                    .padding(vertical = 15.dp),
                contentAlignment = Alignment.Center
            ) {
                Mono(label, 11.sp, if (i == selected) Sig.Ink else Color.White, bold = true)
            }
        }
    }
}
