package com.privateai.bro

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import kotlin.math.sqrt

/** The owner's voice profile: mean speaker vector, encrypted in the Android Keystore-backed vault. */
object VoiceProfile {
    private const val ALIAS = "bro_voice_key"

    fun exists() = Prefs.voiceBlob != null

    fun save(vectors: List<FloatArray>) {
        val n = vectors.first().size
        val mean = FloatArray(n)
        vectors.forEach { v -> for (i in 0 until n) mean[i] += v[i] / vectors.size }
        val arr = JSONArray()
        mean.forEach { arr.put(it.toDouble()) }
        Prefs.voiceBlob = Vault.encrypt(ALIAS, arr.toString())
    }

    private fun load(): FloatArray? {
        val blob = Prefs.voiceBlob ?: return null
        return try {
            val a = JSONArray(Vault.decrypt(ALIAS, blob))
            FloatArray(a.length()) { a.getDouble(it).toFloat() }
        } catch (e: Exception) {
            null
        }
    }

    /** Cosine distance (0 = identical direction, higher = less alike). Null if there is no usable profile. */
    fun distance(v: FloatArray): Float? {
        val p = load() ?: return null
        if (p.size != v.size) return null
        var dot = 0.0; var na = 0.0; var nb = 0.0
        for (i in p.indices) { dot += p[i] * v[i]; na += p[i] * p[i]; nb += v[i] * v[i] }
        if (na == 0.0 || nb == 0.0) return null
        return (1.0 - dot / (sqrt(na) * sqrt(nb))).toFloat()
    }

    fun delete() { Prefs.voiceBlob = null }
}

/** Records the owner saying "hey bro" five times and builds the profile. Audio is never stored. */
object Enroller {
    private val main = Handler(Looper.getMainLooper())
    var progress by mutableStateOf("")
    var running by mutableStateOf(false)
    private const val NEEDED = 5

    private fun post(msg: String) { main.post { progress = msg } }

    fun start(ctx: Context, onDone: () -> Unit) {
        if (running) return
        running = true
        val app = ctx.applicationContext
        ListenService.stop(app)
        Thread {
            val engine = WakeFactory.create()
            val vectors = ArrayList<FloatArray>()
            try {
                val err = engine.load(app)
                if (err != null) { post(err.uppercase()); return@Thread }
                if (!ModelManager.spkReady(app)) { post("VOICE MODEL IS MISSING. DOWNLOAD IT FIRST."); return@Thread }
                val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val rec = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8192)
                )
                if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); post("MICROPHONE IS BUSY OR BLOCKED."); return@Thread }
                val buf = ShortArray(2048)
                val end = SystemClock.elapsedRealtime() + 60_000
                post("SAY \"HEY BRO\"  0/$NEEDED")
                rec.startRecording()
                while (vectors.size < NEEDED && SystemClock.elapsedRealtime() < end) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    val hit = engine.feed(buf, n) ?: continue
                    if (hit.text.contains("bro") && hit.speaker != null) {
                        vectors.add(hit.speaker)
                        post("GOT IT  ${vectors.size}/$NEEDED. SAY IT AGAIN.")
                    }
                }
                rec.stop(); rec.release()
                if (vectors.size >= NEEDED) {
                    VoiceProfile.save(vectors)
                    post("SAVED. ONLY YOUR VOICE WILL WAKE BRO WHEN \"ONLY MY VOICE\" IS ON.")
                } else {
                    post("TIMED OUT. ONLY ${vectors.size}/$NEEDED HEARD. TRY IN A QUIETER PLACE.")
                }
            } catch (e: Throwable) {
                post("ENROLL FAILED: ${e.message}")
            } finally {
                engine.close()
                main.post { running = false; onDone() }
            }
        }.start()
    }
}
