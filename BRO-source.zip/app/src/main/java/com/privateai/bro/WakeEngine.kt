package com.privateai.bro

/** A phrase heard by the wake engine, with the speaker vector of that utterance when available. */
class WakeHit(val text: String, val speaker: FloatArray?)

interface WakeEngine {
    /** Returns null on success or a short error message. */
    fun load(ctx: android.content.Context): String?
    /** Feed 16 kHz mono PCM. Returns a hit when an utterance finished. */
    fun feed(buf: ShortArray, n: Int): WakeHit?
    fun close()
}
