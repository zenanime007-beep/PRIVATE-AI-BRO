package com.privateai.bro

import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LensScreen(fg: Color, head: Color) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Display("LENS", 84.sp, head)
        Mono("THIS BUILD WAS MADE WITHOUT CAMERA AND SCREEN READING.", 12.sp, fg, bold = true)
    }
}

class ScreenCaptureService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopSelf()
        return START_NOT_STICKY
    }
}
