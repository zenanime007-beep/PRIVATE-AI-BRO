package com.privateai.bro

/** Build without the Vosk wake engine: only double-clap and tap activation work. */
object WakeFactory {
    fun create(): WakeEngine = object : WakeEngine {
        override fun load(ctx: android.content.Context): String? = "This build was made without the wake-word engine."
        override fun feed(buf: ShortArray, n: Int): WakeHit? = null
        override fun close() {}
    }
}
