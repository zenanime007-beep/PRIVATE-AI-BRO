package com.privateai.bro

import android.content.Context
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.SpeakerModel

/** Offline keyword spotting ("hey bro" / "hello bro") plus a speaker vector per utterance, using Vosk. */
class VoskWake : WakeEngine {
    private var model: Model? = null
    private var spk: SpeakerModel? = null
    private var rec: Recognizer? = null

    override fun load(ctx: Context): String? {
        val dir = ModelManager.wakeModelDir(ctx)
        if (!dir.exists()) return "Wake-word model is not downloaded yet."
        return try {
            LibVosk.setLogLevel(LogLevel.WARNINGS)
            val m = Model(dir.absolutePath)
            model = m
            val r = Recognizer(m, 16000f, "[\"hey bro\", \"hello bro\", \"[unk]\"]")
            val sd = ModelManager.spkModelDir(ctx)
            if (sd.exists()) {
                val s = SpeakerModel(sd.absolutePath)
                spk = s
                r.setSpeakerModel(s)
            }
            rec = r
            null
        } catch (e: Throwable) {
            e.message ?: "Could not load the wake-word model."
        }
    }

    override fun feed(buf: ShortArray, n: Int): WakeHit? {
        val r = rec ?: return null
        if (!r.acceptWaveForm(buf, n)) return null
        val j = JSONObject(r.result)
        val text = j.optString("text")
        if (text.isBlank()) return null
        val arr = j.optJSONArray("spk")
        val vec = if (arr != null) FloatArray(arr.length()) { arr.getDouble(it).toFloat() } else null
        return WakeHit(text, vec)
    }

    override fun close() {
        try { rec?.close() } catch (e: Throwable) {}
        try { spk?.close() } catch (e: Throwable) {}
        try { model?.close() } catch (e: Throwable) {}
    }
}

object WakeFactory {
    fun create(): WakeEngine = VoskWake()
}
