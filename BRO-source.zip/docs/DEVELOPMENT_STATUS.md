# PRIVATE AI – BRO status (v0.6.0)

Nothing below is marked TESTED. No build has been run and nothing has been tried on a real phone yet.
IMPLEMENTED means source code exists. Only a CI build and a test on the Vivo Y20G can move it to TESTED.

| Feature | Status | Notes |
|---|---|---|
| PIN + fingerprint lock, escalating lockout, erase-and-reset | IMPLEMENTED | Lockout counter survives app restarts |
| Floating orb, top pill, 11 orb states, mic-level reactive orb | IMPLEMENTED | |
| Tap-to-talk, TTS, rule-based commands (EN / Tamil script / Tanglish keywords) | IMPLEMENTED | Uses Android's speech service; it may use the network |
| Open apps (real icons), torch, volume, timer, alarm, Wi-Fi/Bluetooth settings | IMPLEMENTED | Android does not allow toggling Wi-Fi/Bluetooth directly |
| Contacts: call / SMS / WhatsApp prepared for your final tap | IMPLEMENTED | Duplicate-name picker and emoji names: NOT YET |
| Encrypted local memory (Keystore AES-GCM), view/delete/clear | IMPLEMENTED | Voice recall needs a recent unlock |
| Always-on "Hey Bro / Hello Bro" (Vosk, offline, models downloaded once) | IMPLEMENTED | Needs `wake=true` build and the ~55 MB model download |
| Owner-voice-only wake (Vosk speaker vector, cosine distance) | IMPLEMENTED | Threshold must be tuned on the phone; can be fooled by a recording |
| Double-clap wake | IMPLEMENTED | Loud noises can false-trigger |
| Camera: QR/barcode, text (Latin only), object labels (ML Kit, on-device) | IMPLEMENTED | Tamil OCR not supported by ML Kit |
| Screen reading (MediaProjection + OCR, one shot, user-approved) | IMPLEMENTED | No summary or explanation, just the text |
| Routines (lists of voice commands, "start study mode") | IMPLEMENTED | Calls/messages are blocked inside routines |
| Free / Premium / Owner gates, orb themes, size, pitch | IMPLEMENTED | Owner = whoever set up the install; no payment, no bypass code |
| Diagnostics: RAM, command latency, voice distance | IMPLEMENTED | Latency is end-of-speech → reply only |
| Offline Tamil speech recognition | DEVICE LIMITATION | Depends on the phone's speech engine; test with airplane mode |
| Offline Tamil TTS | DEVICE LIMITATION | Check TUNE → CHECK VOICE SUPPORT |
| Translation, notification reading, smart home | NOT STARTED | |
| Release signing / release APK | NOT STARTED | Debug APK installs fine |
| CI build success, Vivo Y20G install, battery / RAM / crash testing | NOT DONE | |
